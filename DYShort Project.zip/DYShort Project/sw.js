const CACHE_NAME = "dyshort-v5";

const STATIC_ASSETS = [

  "/",
  "/index.html",
  "/blog.html",
  "/article.html",
  "/manifest.json",

  "https://files.catbox.moe/2qz5sl.png"

];

/* INSTALL */

self.addEventListener("install",(event)=>{

  event.waitUntil(

    caches.open(CACHE_NAME)
    .then((cache)=>{

      return cache.addAll(STATIC_ASSETS);

    })

  );

  self.skipWaiting();

});

/* ACTIVATE */

self.addEventListener("activate",(event)=>{

  event.waitUntil(

    caches.keys().then((keys)=>{

      return Promise.all(

        keys.map((key)=>{

          if(key !== CACHE_NAME){

            return caches.delete(key);

          }

        })

      );

    })

  );

  self.clients.claim();

});

/* MESSAGE — dipicu dari admin panel via cache-buster.js untuk memaksa
   semua browser pengguna membersihkan cache lama */

self.addEventListener("message", (event) => {

  if (event.data && event.data.type === "CLEAR_ALL_CACHES") {

    event.waitUntil(

      caches.keys()
      .then((keys) => Promise.all(keys.map((key) => caches.delete(key))))
      .then(() => self.skipWaiting())
      .then(() => self.clients.matchAll())
      .then((clients) => {
        clients.forEach((client) => client.postMessage({ type: "CACHE_CLEARED" }));
      })

    );

  }

});

/* FETCH */

self.addEventListener("fetch",(event)=>{

  if(event.request.method !== "GET")
  return;

  // Halaman HTML (navigasi) selalu diambil dari network dulu, supaya
  // update konten terbaru langsung tampil tanpa menunggu cache basi.
  if (event.request.mode === "navigate") {

    event.respondWith(

      fetch(event.request)
      .then((response) => {

        const cloned = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, cloned));
        return response;

      })
      .catch(() => caches.match(event.request).then((cached) => cached || caches.match("/")))

    );

    return;

  }

  event.respondWith(

    caches.match(event.request)
    .then((cached)=>{

      if(cached){

        return cached;

      }

      return fetch(event.request)
      .then((response)=>{

        const cloned =
        response.clone();

        caches.open(CACHE_NAME)
        .then((cache)=>{

          cache.put(
            event.request,
            cloned
          );

        });

        return response;

      })

      .catch(()=>{

        return caches.match("/");

      });

    })

  );

});