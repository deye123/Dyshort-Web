(function () {
  function getSavedTheme() {
    try {
      return localStorage.getItem("theme") || "dark";
    } catch (e) {
      console.warn("Akses LocalStorage diblokir oleh browser.");
      return "dark";
    }
  }
  function setSavedTheme(theme) {
    try {
      localStorage.setItem("theme", theme);
    } catch (e) {
      console.warn("Gagal menyimpan preferensi tema.");
    }
  }
  const saved = getSavedTheme();
  // Menerapkan tema lebih awal jika mode light tersimpan
  if (saved === "light") {
    document.documentElement.classList.add("light-theme");
  }
  function updateThemeButton() {
    const btn = document.getElementById("themeBtn");
    if (!btn) return;

    btn.textContent = document.documentElement.classList.contains("light-theme")
      ? "☀️"
      : "🌓";
  }
  window.toggleTheme = function () {
    document.documentElement.classList.toggle("light-theme");
    
    const isLight = document.documentElement.classList.contains("light-theme");
    setSavedTheme(isLight ? "light" : "dark");
    
    updateThemeButton();
  };
  window.addEventListener("DOMContentLoaded", () => {
    updateThemeButton();
    const btn = document.getElementById("themeBtn");
    if (btn) {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        window.toggleTheme();
      });
    }
  });
  if (document.readyState === "interactive" || document.readyState === "complete") {
    updateThemeButton();
  }
})();