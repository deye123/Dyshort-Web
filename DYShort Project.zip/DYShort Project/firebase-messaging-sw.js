// Import script Firebase versi compat
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js');

// Inisialisasi Firebase dengan konfigurasi lengkap Anda
firebase.initializeApp({
  apiKey: "AIzaSyBYWLLSxAdWQh8l_gFTVVpoHu90AM4Pit4",
  authDomain: "dyaltheme.firebaseapp.com",
  databaseURL: "https://dyaltheme-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "dyaltheme",
  storageBucket: "dyaltheme.firebasestorage.app",
  messagingSenderId: "273589813698",
  appId: "1:273589813698:web:10bee0ed5a59a8624ad65b"
});

// Ambil instance messaging
const messaging = firebase.messaging();