document.addEventListener("DOMContentLoaded", async () => {
  const videoEl = document.getElementById("myVideo");
  if (!videoEl || typeof videojs === "undefined") return;

  const player = videojs("myVideo");

  const state = {
    currentSlug: "",
    buttonLink: "",
    redirectLink: "",
    overlayShown: false,
    overlayDismissed: false,
    overlayTimer: null,
    triedFullscreen: false,
  };

  function getSlugFromPath() {
    let path = window.location.pathname.replace(/^\/+|\/+$/g, "");
    let isMp4 = false;

    if (path.toLowerCase().endsWith(".mp4")) {
      path = path.slice(0, -4);
      isMp4 = true;
    }

    let slug = path.replace(/\./g, "_");
    if (isMp4 && !slug.endsWith("_mp4")) slug += "_mp4";
    return slug;
  }

  function saveTime() {
    if (!state.currentSlug) return;
    sessionStorage.setItem(
      `video_time_${state.currentSlug}`,
      String(videoEl.currentTime || 0)
    );
  }

  function loadTime() {
    if (!state.currentSlug) return;
    const savedTime = sessionStorage.getItem(`video_time_${state.currentSlug}`);
    if (!savedTime) return;

    const t = parseFloat(savedTime);
    if (!Number.isNaN(t)) videoEl.currentTime = t;
  }

  function pauseSafe() {
    try { videoEl.pause(); } catch (_) {}
    try { player.pause(); } catch (_) {}
  }

  function clearOverlayTimer() {
    if (state.overlayTimer) {
      clearTimeout(state.overlayTimer);
      state.overlayTimer = null;
    }
  }

  function tryRequestFullscreen() {
    const el = player.el();
    if (!el || document.fullscreenElement) return;

    try {
      if (el.requestFullscreen) el.requestFullscreen();
      else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
      else if (player.requestFullscreen) player.requestFullscreen();
    } catch (_) {}
  }

  function updateMeta(selector, value) {
    if (!value) return;
    const el = document.querySelector(selector);
    if (el) el.setAttribute("content", value);
  }

  function setVideoSource(url) {
  if (!url) return;
  videoEl.innerHTML = "";
  const source = document.createElement("source");
  source.src = url;
  source.type = "video/mp4";
  videoEl.appendChild(source);
  videoEl.load();
}

  function createOverlay() {
    const playerEl = player.el();
    if (!playerEl) return null;

    const existing = playerEl.querySelector(".vjs-download-overlay");
    if (existing) return existing;

    const overlay = document.createElement("div");
    overlay.className = "vjs-download-overlay";
    overlay.innerHTML = `
      <div class="downloadCard" role="dialog" aria-modal="true">
        <div class="downloadTitle">WATCH FULL VIDEO</div>
        <div class="downloadText">Continue watching the full premium video experience</div>
        <div class="downloadArrowWrap"><div class="downloadArrow"></div></div>
        <div class="btnRow">
          <a id="vjsDownloadBtn" class="btnDownload" href="#" rel="noopener">WATCH NOW</a>
        </div>
      </div>
    `;

    playerEl.appendChild(overlay);
    return overlay;
  }

  function showOverlay() {
    if (state.overlayShown || state.overlayDismissed) return;

    const overlay = createOverlay();
    if (!overlay) return;

    const btn = overlay.querySelector("#vjsDownloadBtn");
    if (btn) {
      if (state.buttonLink) {
        btn.setAttribute("href", state.buttonLink);
        btn.setAttribute("target", "_blank");
      } else {
        btn.removeAttribute("href");
        btn.setAttribute("aria-disabled", "true");
        btn.style.pointerEvents = "none";
        btn.style.opacity = ".6";
      }

      btn.addEventListener(
        "click",
        (e) => {
          if (state.overlayDismissed) return;
          e.preventDefault();

          state.overlayDismissed = true;
          state.overlayShown = true;
          overlay.classList.remove("active");
          fetch("/api/track-ad", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ slug: state.currentSlug })
          }).catch(err => console.error(err));
          if (state.buttonLink) {
            window.open(state.buttonLink, "_blank");
          }

          setTimeout(() => {
            saveTime();
            if (state.redirectLink) {
              window.location.href = state.redirectLink;
            }
          }, 1200);

          pauseSafe();
        },
        { once: true }
      );
    }

    overlay.classList.add("active");
    state.overlayShown = true;
    pauseSafe();
  }

  function scheduleOverlayAfter3s() {
    if (state.overlayShown || state.overlayDismissed) return;
    clearOverlayTimer();
    state.overlayTimer = setTimeout(() => {
      showOverlay();
      state.overlayTimer = null;
    }, 3000);
  }

  async function loadLinkData() {
    state.currentSlug = getSlugFromPath();

    try {
      const res = await fetch(
        `/api/get-link?slug=${encodeURIComponent(state.currentSlug)}`,
        { cache: "no-store" }
      );

      const json = await res.json();
      if (!json.success || !json.data) return;

      const data = json.data;
      const fields = data.fields || {};

      setVideoSource(fields.videoUrl || "");
      state.buttonLink =
  `/go/${encodeURIComponent(state.currentSlug)}/button`;

state.redirectLink =
  `/go/${encodeURIComponent(state.currentSlug)}/redirect`;

      if (data.ogTitle) document.title = data.ogTitle;
      updateMeta('meta[property="og:title"]', data.ogTitle);
      updateMeta('meta[property="og:description"]', data.ogDesc);
      updateMeta('meta[property="og:image"]', data.ogImage);
    } catch (err) {
      console.error("Failed to load link data:", err);
    }
  }

  function bindPlaybackGuards() {
    let lastKnownTime = 0;

    videoEl.addEventListener("loadedmetadata", loadTime);

    videoEl.addEventListener("timeupdate", () => {
      lastKnownTime = videoEl.currentTime;
    });

    videoEl.addEventListener("seeking", () => {
      if (videoEl.currentTime > lastKnownTime + 0.5) {
        videoEl.currentTime = lastKnownTime;
      }
    });

    videoEl.addEventListener("ratechange", () => {
      if (videoEl.playbackRate !== 1) videoEl.playbackRate = 1;
    });
  }

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && state.overlayDismissed) {
      setTimeout(() => {
        player.play().catch(() => {});
      }, 150);
    }
  });

  player.on("play", () => {
    if (!state.triedFullscreen) {
      state.triedFullscreen = true;
      tryRequestFullscreen();
    }
    scheduleOverlayAfter3s();
  });

  player.on("pause", clearOverlayTimer);
  player.on("ended", clearOverlayTimer);

  player.ready(() => {
    player.bigPlayButton.show();
    player.poster("");
  });

  bindPlaybackGuards();
  await loadLinkData();
  setInterval(saveTime, 1000);
  createOverlay();
});