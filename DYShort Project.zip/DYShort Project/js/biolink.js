// IMPORT FIREBASE SUDAH DIPERBAIKI (Ada update & increment)
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getDatabase, ref, get, push, set, increment } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyBYWLLSxAdWQh8l_gFTVVpoHu90AM4Pit4",
  authDomain: "auth.dyshort.pro",
  databaseURL: "https://dyaltheme-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "dyaltheme",
  storageBucket: "dyaltheme.firebasestorage.app",
  messagingSenderId: "273589813698",
  appId: "1:273589813698:web:10bee0ed5a59a8624ad65b"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const appBox = document.getElementById("app");

function toast(text, type="success"){
  const t = document.getElementById("toast");
  t.className = type;
  t.innerText = text;
  t.style.display = "block";
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(()=>t.style.display="none", 2400);
}

function escapeHtml(str=""){
  return String(str)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#39;");
}

function getUsername(){
  const qs = new URLSearchParams(location.search).get("user");
  if(qs){
    return qs.trim().toLowerCase();
  }

  const parts = location.pathname.split("/").filter(Boolean);

  if(parts.length >= 2 && parts[0] === "u"){
    return parts[1].trim().toLowerCase();
  }

  const reserved = [
    "dashboard", "dashboard.html", "media", "media.html",
    "blog", "blog.html", "article", "article.html",
    "login", "login.html", "register", "register.html",
    "admin", "api", "assets", "biolink.html"
  ];

  if(parts.length === 1 && !reserved.includes(parts[0])){
    return parts[0].trim().toLowerCase();
  }
  return "";
}

function isScheduledActive(data){
  const now = Date.now();
  const from = data.activeFrom ? new Date(data.activeFrom).getTime() : null;
  const until = data.activeUntil ? new Date(data.activeUntil).getTime() : null;

  if(from && now < from) return false;
  if(until && now > until) return false;
  return true;
}

function resolveTheme(data){
  const theme = data.theme || "green";
  document.body.classList.remove("blue","purple","orange");
  if(theme === "blue" || theme === "purple" || theme === "orange"){
    document.body.classList.add(theme);
  }

  if(data.primaryColor && /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(data.primaryColor)){
    document.documentElement.style.setProperty("--primary", data.primaryColor);
  }else{
    const map = { green:"#00ff99", blue:"#00aaff", purple:"#bb66ff", orange:"#ff9f43" };
    document.documentElement.style.setProperty("--primary", map[theme] || "#00ff99");
  }

  if(data.customCss){
    let styleEl = document.getElementById("custom-bio-css");
    if(!styleEl){
      styleEl = document.createElement("style");
      styleEl.id = "custom-bio-css";
      document.head.appendChild(styleEl);
    }
    styleEl.textContent = String(data.customCss);
  }
}

function socialLabel(key){
  return key.charAt(0).toUpperCase() + key.slice(1);
}

function socialIcon(key){
  const icons = {
    instagram:"📸",
    youtube:"▶",
    tiktok:"🎵",
    github:"⌂",
    telegram:"✈",
    discord:"💬"
  };
  return icons[key] || "•";
}

function buildLinkHtml(item, i){
  const title = escapeHtml(item.title || "");
  const url = escapeHtml(item.url || "#");
  const icon = escapeHtml(item.icon || "🔗");
  const thumb = item.thumbnail ? `<img src="${escapeHtml(item.thumbnail)}" alt="">` : "";
  const pinned = item.pinned ? `<div class="previewLinkMeta">Pinned</div>` : "";
  
  // ONCLICK SUDAH DITAMBAHKAN DI SINI
  return `
    <a class="previewLink" href="${url}" target="${item.newTab === false ? "_self" : "_blank"}" onclick="trackLinkClick(${i})">
      <span class="previewLinkLeft">
        <span class="previewLinkIcon">${thumb || icon}</span>
        <span class="previewLinkText">
          <div>${title}</div>
          <div class="previewLinkMeta">${pinned}</div>
        </span>
      </span>
      <span>→</span>
    </a>
  `;
}

function buildProductHtml(item){
  const title = escapeHtml(item.title || "");
  const price = escapeHtml(item.price || "");
  const image = escapeHtml(item.image || "");
  const url = escapeHtml(item.url || "#");
  return `
    <div class="product">
      <img src="${image}" alt="${title}">
      <h4>${title}</h4>
      <p>${price}</p>
      <a class="buyBtn" href="${url}" target="_blank">Open</a>
    </div>
  `;
}

function buildGalleryHtml(src){
  return `<img src="${escapeHtml(src)}" alt="gallery">`;
}

// LOGIKA TRACKING SUDAH DIISI
async function trackView(username){
  try {
    await set(ref(db, `bios/${username}/views`), increment(1));
  } catch(err) {
    console.error("Gagal update views", err);
  }
}

async function trackLinkClick(username){
  try {
    await set(ref(db, `bios/${username}/clicks`), increment(1));
  } catch(err) {
    console.error("Gagal update clicks", err);
  }
}

window.trackLinkClick = async function(index){
  const username = window.__bioUsername;
  if(!username) return;
  try{
    await trackLinkClick(username);
  }catch(err){
    console.error(err);
  }
};

window.copyBioUrl = function(){
  navigator.clipboard.writeText(location.href);
  toast("Bio URL copied");
};

// Fungsi buka-tutup pop-up QR Code
window.toggleQrModal = function(show) {
  const modal = document.getElementById("qrModal");
  if (modal) {
    modal.style.display = show ? "flex" : "none";
  }
};

// Modifikasi fungsi share agar selalu memunculkan Pop-up QR Code + Salin Link otomatis
window.shareBio = function() {
  navigator.clipboard.writeText(location.href);
  toast("Link copied & QR Code opened!");
  window.toggleQrModal(true); // Memunculkan pop-up melayang
};



async function renderLockedBio(data, username){
  appBox.innerHTML = `
    <div class="profile">
      <div class="locked">
        <h1>Locked</h1>
        <p>Bio ini diproteksi password.</p>
        <div class="btnRow">
          <input id="bioPasswordInput" class="input" style="max-width:320px" type="password" placeholder="Masukkan password">
          <button class="smallBtn" onclick="unlockBio()">Unlock</button>
        </div>
      </div>
    </div>
  `;

  window.unlockBio = async function(){
    const val = document.getElementById("bioPasswordInput").value;
    if(val === data.bioPassword){
      localStorage.setItem(`bio-unlock-${username}`, "1");
      loadBio();
    }else{
      toast("Password salah", "error");
    }
  };
}

async function loadBio(){
  const username = getUsername();
  window.__bioUsername = username;

  if(!username){
    appBox.innerHTML = `
      <div class="notfound">
        <h1>404</h1>
        <p>User not found</p>
      </div>
    `;
    return;
  }

  try{
    const snap = await get(ref(db, `bios/${username}`));

    if(!snap.exists()){
      appBox.innerHTML = `
        <div class="notfound">
          <h1>404</h1>
          <p>Bio not found</p>
        </div>
      `;
      return;
    }

    const data = snap.val();

    if(!isScheduledActive(data)){
      appBox.innerHTML = `
        <div class="locked">
          <h1>Not Active</h1>
          <p>Bio ini belum aktif atau sudah berakhir.</p>
        </div>
      `;
      return;
    }

    const unlocked = localStorage.getItem(`bio-unlock-${username}`) === "1";
    if(data.passwordMode && data.bioPassword && !unlocked){
      await renderLockedBio(data, username);
      return;
    }

    resolveTheme(data);
    document.title = `${data.name || username} — DYShort Bio`;

    // PEMANGGILAN TRACK VIEW ADA DI SINI
    trackView(username);

    const links = data.links ? Object.values(data.links) : [];
    const socials = data.socials || {};
    const gallery = data.gallery ? Object.values(data.gallery) : [];
    const products = data.products ? Object.values(data.products) : [];

    window.__bioEmailLabel = data.emailLabel || "Subscribe";

    const socialsHtml = Object.entries(socials)
      .filter(([_, url]) => url)
      .map(([key, url]) => `
        <a href="${escapeHtml(url)}" target="_blank">${socialIcon(key)} ${socialLabel(key)}</a>
      `).join("");

    const pinnedHtml = (data.pinned && data.pinned.title && data.pinned.url) ? `
      <div class="pinned">
        <div class="sectionHead" style="margin-bottom:8px;">
          <h3 style="margin:0">Pinned</h3>
          <span>${escapeHtml(data.pinned.icon || "⭐")}</span>
        </div>
        <a href="${escapeHtml(data.pinned.url)}" target="_blank">${escapeHtml(data.pinned.title)}</a>
      </div>
    ` : "";

    const musicHtml = data.music ? `
      <div class="sectionBlock musicBox">
        <div class="sectionHead">
          <h3>Music</h3>
          <span>Autoplay jika browser mengizinkan</span>
        </div>
        <audio controls ${data.musicAutoplay ? "autoplay" : ""} loop src="${escapeHtml(data.music)}"></audio>
      </div>
    ` : "";

    const videoHtml = data.youtubeEmbed ? `
      <div class="sectionBlock videoBox">
        <div class="sectionHead">
          <h3>Featured Video</h3>
          <span>YouTube / embed</span>
        </div>
        <iframe src="${escapeHtml(data.youtubeEmbed)}" allowfullscreen></iframe>
      </div>
    ` : "";

    const galleryHtml = gallery.length ? `
      <div class="sectionBlock">
        <div class="sectionHead">
          <h3>Gallery</h3>
          <span>${gallery.length} photos</span>
        </div>
        <div class="gallery">
          ${gallery.map(buildGalleryHtml).join("")}
        </div>
      </div>
    ` : "";

    const productsHtml = products.length ? `
      <div class="sectionBlock">
        <div class="shopGrid">
          ${products.map(buildProductHtml).join("")}
        </div>
      </div>
    ` : "";

    const qr = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(location.href)}`;

    const commentsHtml = data.allowComments ? `
      <div class="sectionBlock">
        <div class="sectionHead">
          <h3>Comments</h3>
          <span>Visitor messages</span>
        </div>
        <textarea id="commentText" class="textarea" placeholder="Tulis komentar..."></textarea>
        <button class="subscribeBtn" onclick="postComment()">Kirim Komentar</button>
        <div id="commentsList" style="margin-top:16px;display:flex;flex-direction:column;gap:10px;"></div>
      </div>
    ` : "";

                appBox.innerHTML = `
      <div class="profile">
        
        <button class="topShareBtn" onclick="shareBio()" title="Share Bio">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
        </button>

        <div class="cover" id="coverBox" style="background-image:url('${escapeHtml(data.cover || "")}')">
          ${data.coverVideo ? `<video autoplay muted loop playsinline src="${escapeHtml(data.coverVideo)}"></video>` : ""}
        </div>

        <div class="content">
          <div class="avatar">
            <img src="${escapeHtml(data.avatar || "https://i.ibb.co/2M7rtLk/user.png")}" alt="avatar">
          </div>

          <div class="nameRow">
            <div class="name">${escapeHtml(data.name || username)}</div>
            ${data.verified ? `<span class="verified">✔ VERIFIED</span>` : ""}
          </div>

          <div class="bioText">${escapeHtml(data.bio || "")}</div>

          ${data.pinned && data.pinned.title && data.pinned.url ? pinnedHtml : ""}

          <div class="linksWrap">
            <div class="previewLinks">
              ${links.filter(item => !item.hidden).map((item, i) => buildLinkHtml(item, i)).join("")}
            </div>
          </div>

          ${musicHtml}
          ${videoHtml}
          ${productsHtml}
          ${galleryHtml}

          ${socialsHtml ? `
          <div class="sectionBlock">
            <div class="previewSocials">
              ${socialsHtml}
            </div>
          </div>
          ` : ""}

          ${commentsHtml}

          ${data.hideBranding ? "" : `<div class="footer">Powered by <a href="https://dyshort.pro" target="_blank">DYShort</a></div>`}
        </div>
      </div>

      <div id="qrModal" class="qr-modal" onclick="toggleQrModal(false)">
        <div class="qr-modal-content" onclick="event.stopPropagation()">
          <h3 style="color:#fff; margin-bottom: 5px; font-size: 18px;">Scan QR Code</h3>
          <p style="color:#777; font-size:13px;">Scan untuk membuka bio ini</p>
          <img src="${qr}" alt="QR Code">
          <button class="qr-close-btn" onclick="toggleQrModal(false)">Close</button>
        </div>
      </div>
    `;



    window.__bioData = data;

    if(data.customCss){
      let styleEl = document.getElementById("bio-custom-css");
      if(!styleEl){
        styleEl = document.createElement("style");
        styleEl.id = "bio-custom-css";
        document.head.appendChild(styleEl);
      }
      styleEl.textContent = data.customCss;
    }

    if(data.allowComments){
      loadComments(username);
      window.postComment = async function(){
        const txt = document.getElementById("commentText").value.trim();
        if(!txt){
          toast("Tulis komentar dulu", "error");
          return;
        }
        await pushComment(username, txt);
        document.getElementById("commentText").value = "";
        toast("Komentar terkirim");
      };
    }

  }catch(err){
    console.error(err);
    appBox.innerHTML = `
      <div class="notfound">
        <h1>Error</h1>
        <p>Failed loading bio</p>
      </div>
    `;
  }
}

async function pushComment(username, text){
  const item = {
    text,
    created: Date.now()
  };
  const refComments = ref(db, `bioComments/${username}`);
  const newRef = await push(refComments, item);
  return newRef;
}

function escapeText(s=""){
  return String(s)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;");
}

async function loadComments(username){
  const boxId = "commentsList";
  const box = document.getElementById(boxId);
  if(!box) return;

  try{
    const snap = await get(ref(db, `bioComments/${username}`));
    if(!snap.exists()){
      box.innerHTML = `<div style="color:#777">Belum ada komentar</div>`;
      return;
    }

    const data = snap.val();
    const arr = Object.values(data).sort((a,b)=>(b.created||0)-(a.created||0));

    box.innerHTML = arr.map(item => `
      <div style="
        background:#111;
        border:1px solid #222;
        border-radius:12px;
        padding:12px 14px;
        text-align:left;
        color:#ddd;
        line-height:1.7;
      ">
        ${escapeText(item.text)}
      </div>
    `).join("");

  }catch(err){
    console.error(err);
  }
}

loadBio();