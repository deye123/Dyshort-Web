import app from "/js/firebase-init.js";
import {
  getDatabase,
  ref,
  get,
  onValue,
  update
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

import {
  getAuth,
  onAuthStateChanged,
  signOut,
  getRedirectResult
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

/* ===========================
   FIREBASE INITIALIZATION
=========================== */
const db = getDatabase(app);
const auth = getAuth(app);

console.log("🔐 home.js: Firebase initialized");

/* GLOBAL VARIABLES */
let currentUser = null;
let domainsUnsubscribe = null;
let authCheckDone = false;

/* ===========================
   HANDLE REDIRECT RESULT
=========================== */
try {
  const result = await getRedirectResult(auth);
  if (result?.user) {
    console.log("✅ User redirected from OAuth provider:", result.user.email);
  }
} catch (err) {
  console.error("❌ Redirect result error:", err);
}

/* ===========================
   TOAST NOTIFICATION HELPER
=========================== */
function showToast(message, type = "success") {
  const toast = document.getElementById("toast");
  if (!toast) return;

  toast.innerText = message;
  toast.className = "";
  toast.classList.add(type, "show");

  setTimeout(() => {
    toast.classList.remove("show");
  }, 3000);
}
window.showToast = showToast;

/* ===========================
   NAVIGATION FUNCTIONS
=========================== */
window.openMediaPage = function () {
  const user = auth.currentUser;
  if (!user) {
    showToast("Login required", "error");
    setTimeout(() => { location.href = "/"; }, 800);
    return;
  }
  location.href = "/media.html";
};

window.openBiolink = function () {
  const user = auth.currentUser;
  if (!user) {
    showToast("Login required", "error");
    setTimeout(() => { location.href = "/"; }, 800);
    return;
  }
  location.href = "/bio-dashboard.html";
};

window.handleMediaCdnClick = function () {
  if (!currentUser) {
    showToast("Silakan login terlebih dahulu untuk mengunggah media.", "error");
    setTimeout(() => { location.href = "/"; }, 1000);
    return;
  }
  const fileInput = document.getElementById("mediaFile");
  if (fileInput) fileInput.click();
};

/* ===========================
   LOAD DOMAINS
=========================== */
function loadDomains(userPlan, isExpired, userRole) {
  const domainSelect = document.getElementById("domainSelect");
  if (!domainSelect) return;

  const isPremiumUser = userPlan && (userPlan.includes("premium") || userPlan.includes("admin")) && !isExpired;
  const isAdmin = (userRole === "admin");

  if (domainsUnsubscribe) {
    domainsUnsubscribe();
  }

  domainsUnsubscribe = onValue(ref(db, "domains"), (snapshot) => {
    domainSelect.innerHTML = "";
    if (snapshot.exists()) {
      const data = snapshot.val();

      Object.keys(data).forEach((key) => {
        const item = data[key];

        if (item.active === false) return;

        if (item.ownerUid && currentUser && item.ownerUid !== currentUser.uid && !isAdmin) {
          return;
        }

        const opt = document.createElement("option");
        opt.value = item.url;
        const nameText = item.name || item.url;

        if (item.premium === true) {
          if (!isPremiumUser) {
            opt.textContent = `🔒 ${nameText} (Premium Only)`;
            opt.disabled = true;
            opt.style.color = "#666";
          } else {
            opt.textContent = `⭐ ${nameText} (Premium)`;
          }
        } else {
          opt.textContent = nameText;
        }

        domainSelect.appendChild(opt);
      });
    } else {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "No domains";
      domainSelect.appendChild(opt);
    }
  });
}

/* ===========================
   RANDOM STRING GENERATOR
=========================== */
function randomString(length = 5) {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/* ===========================
   LOGOUT
=========================== */
window.logoutUser = async function () {
  try {
    await signOut(auth);
    showToast("Logout berhasil");
    setTimeout(() => { location.href = "/"; }, 1000);
  } catch (err) {
    console.error(err);
    showToast("Logout gagal", "error");
  }
};

/* ===========================
   CREATE SHORTLINK
=========================== */
window.createShort = async function () {
  const user = currentUser;
  if (!user) {
    showToast("Silakan login terlebih dahulu untuk membuat shortlink.", "error");
    return;
  }

  try {
    const userRef = ref(db, 'users/' + user.uid);
    const snapshot = await get(userRef);

    let isPremium = false;
    let isAdmin = false;

    if (snapshot.exists()) {
      const userData = snapshot.val();

      const isExpired = userData.expiredAt && Date.now() > userData.expiredAt;
      isPremium = userData.plan && userData.plan.includes("premium") && !isExpired;
      isAdmin = userData.role === "admin";

      const maxFreeDaily = 10;
      const todayStr = new Date().toISOString().split('T')[0];
      const dailyCount = userData.daily_link_count || 0;
      const lastDate = userData.last_link_date || "";

      if (!isAdmin && !isPremium && lastDate === todayStr && dailyCount >= maxFreeDaily) {
        showToast(`Limit harian gratis (${maxFreeDaily} link) habis! Upgrade ke Premium.`, "error");
        setTimeout(() => { location.href = "/pricing.html"; }, 1500);
        return;
      }
    }
  } catch (err) {
    console.error("Gagal memvalidasi kuota:", err);
  }

  const templateSelect = document.getElementById("templateSelect");
  const template = templateSelect ? templateSelect.value : "";

  const domainSelect = document.getElementById("domainSelect");
  const domain = domainSelect ? domainSelect.value : "";

  if (!domain) {
    showToast("Silakan pilih domain terlebih dahulu.", "error");
    return;
  }

  let longUrl = "";
  let videoUrl = "";
  let buttonUrl = "";
  let redirectUrl = "";
  let videoUrls = [];
  let secondUrl = "";

  if (template === "v1dzy") {
    videoUrl = document.getElementById("videoUrlInput")?.value.trim() || "";
    redirectUrl = document.getElementById("buttonUrlInput")?.value.trim() || "";
    if (!videoUrl || !redirectUrl) {
      showToast("Lengkapi semua field untuk Template V1.", "error");
      return;
    }
    longUrl = redirectUrl;
  } else if (template === "template_v2") {
    videoUrl = document.getElementById("videoUrlInputV2")?.value.trim() || "";
    buttonUrl = document.getElementById("buttonUrlInputV2")?.value.trim() || "";
    redirectUrl = document.getElementById("redirectUrlInputV2")?.value.trim() || "";
    if (!videoUrl || !buttonUrl || !redirectUrl) {
      showToast("Lengkapi semua field untuk Template V2.", "error");
      return;
    }
    longUrl = redirectUrl;
  } else if (template === "slicedrive") {
    videoUrls = (document.getElementById("videoUrlsInput")?.value || "")
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);

    let btnUrlSlice = document.getElementById("buttonUrlInputSlice")?.value.trim() || "";
    let autoUrlSlice = document.getElementById("autoRedirectUrlInputSlice")?.value.trim() || "";

    if (!videoUrls.length || (!btnUrlSlice && !autoUrlSlice)) {
      showToast("Lengkapi field video dan minimal satu URL tujuan untuk Template V3.", "error");
      return;
    }
    longUrl = btnUrlSlice || autoUrlSlice;
  } else if (template === "template_v4") {
    redirectUrl = document.getElementById("mainUrlInputV4")?.value.trim() || "";
    secondUrl = document.getElementById("secondUrlInputV4")?.value.trim() || "";
    if (!redirectUrl || !secondUrl) {
      showToast("Lengkapi semua field untuk Template V4.", "error");
      return;
    }
    longUrl = redirectUrl;
  } else if (template === "template_v5") {
    let b1 = document.getElementById("btn1InputV5")?.value.trim() || "";
    let b2 = document.getElementById("btn2InputV5")?.value.trim() || "";
    let b3 = document.getElementById("btn3InputV5")?.value.trim() || "";

    if (!b1 || !b2 || !b3) {
      showToast("Lengkapi semua field (Tombol 1, 2, 3) untuk Template V5.", "error");
      return;
    }
    longUrl = b1;
  } else {
    longUrl = document.getElementById("urlInput")?.value.trim() || "";
    if (!longUrl) {
      showToast("URL tujuan wajib diisi.", "error");
      return;
    }

    if (!longUrl.startsWith("http://") && !longUrl.startsWith("https://")) {
      showToast("URL harus dimulai dengan http:// atau https://", "error");
      return;
    }
  }

  const ogTitle = document.getElementById("ogTitleInput")?.value.trim() || "";
  const ogDesc = document.getElementById("ogDescInput")?.value.trim() || "";
  const ogImage = document.getElementById("ogImageInput")?.value.trim() || "";

  const customAliasInput = document.getElementById("publicAliasInput");
  const originalCustomAlias = customAliasInput ? customAliasInput.value.trim() : "";

  const expireInput = document.getElementById("publicExpireInput");
  const expireVal = expireInput ? expireInput.value : "";
  let expiredAt = null;
  if (expireVal) {
    expiredAt = new Date(expireVal).getTime();
  }

  const cleanedAlias = originalCustomAlias.replace(/\s+/g, "-").replace(/[^a-zA-Z0-9-_.]/g, "");
  const publicSlug = cleanedAlias !== "" ? cleanedAlias : randomString(5);
  const slug = publicSlug.replace(/\./g, "_");

  if (cleanedAlias !== "" && cleanedAlias.replace(".mp4", "").length < 3) {
    showToast("Alias kustom minimal 3 karakter.", "error");
    return;
  }

  try {
    showToast("Membuat shortlink...", "info");

    const cleanDomain = domain.endsWith("/") ? domain : domain + "/";
    const fullShortUrl = cleanDomain + publicSlug;

    const payload = {
      slug: slug,
      publicSlug: publicSlug,
      shortlink: fullShortUrl,
      url: longUrl,
      domain: domain.replace("https://", "").replace("http://", "").replace("/", ""),
      template: template,
      ogTitle: ogTitle,
      ogDesc: ogDesc,
      ogImage: ogImage,
      customAlias: originalCustomAlias,
      uid: currentUser.uid,
      email: currentUser.email || "",
      clicks: 0,
      created: Date.now(),
      expiredAt: expiredAt
    };

    if (template === "v1dzy") {
      payload.fields = { videoUrl, buttonUrl };
    } else if (template === "template_v2") {
      payload.fields = { videoUrl, buttonUrl, redirectUrl };
    } else if (template === "slicedrive") {
      payload.fields = {
        videoUrls: videoUrls,
        buttonUrl: document.getElementById("buttonUrlInputSlice")?.value.trim() || "",
        autoRedirectUrl: document.getElementById("autoRedirectUrlInputSlice")?.value.trim() || ""
      };
    } else if (template === "template_v4") {
      payload.fields = { redirectUrl, secondUrl };
    } else if (template === "template_v5") {
      payload.fields = {
        btn1: document.getElementById("btn1InputV5")?.value.trim() || "",
        btn2: document.getElementById("btn2InputV5")?.value.trim() || "",
        btn3: document.getElementById("btn3InputV5")?.value.trim() || ""
      };
    }

    const token = await currentUser.getIdToken();
    const res = await fetch("https://dyshort-worker.myling.workers.dev/api/create", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });

    const data = await res.json();

    if (!data.success) {
      if (data.message && data.message.includes("Premium")) {
        showToast(data.message, "error");
        setTimeout(() => location.href = "/pricing.html", 1500);
      } else {
        showToast(data.message || "Gagal membuat shortlink", "error");
      }
      return;
    }

    const resultBox = document.getElementById("resultBox");
    const shortLink = document.getElementById("shortLink");

    if (resultBox && shortLink) {
      shortLink.href = fullShortUrl;
      shortLink.textContent = fullShortUrl;
      resultBox.style.display = "block";
      showToast("Shortlink berhasil dibuat!");

      resultBox.scrollIntoView({ behavior: 'smooth' });

      const fieldsToClear = [
        "urlInput", "videoUrlInput", "buttonUrlInput", "publicAliasInput",
        "ogTitleInput", "ogDescInput", "ogImageInput", "publicExpireInput",
        "videoUrlInputV2", "buttonUrlInputV2", "redirectUrlInputV2",
        "videoUrlsInput", "buttonUrlInputSlice", "autoRedirectUrlInputSlice",
        "mainUrlInputV4", "secondUrlInputV4", "btn1InputV5", "btn2InputV5", "btn3InputV5"
      ];
      fieldsToClear.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = "";
      });
    }

  } catch (err) {
    console.error(err);
    showToast("Gagal membuat shortlink: " + err.message, "error");
  }
};

/* ===========================
   AUTH STATE LISTENER (MAIN)
=========================== */
onAuthStateChanged(auth, async (user) => {
  console.log("🔄 Auth state changed");

  // Prevent double execution
  if (authCheckDone) {
    console.log("⚠️ Auth check already done, skipping duplicate");
    return;
  }
  authCheckDone = true;

  if (!user) {
    console.warn("❌ No user found, redirecting to login");
    if (domainsUnsubscribe) {
      domainsUnsubscribe();
      domainsUnsubscribe = null;
    }
    setTimeout(() => {
      location.href = "/";
    }, 1500);
    return;
  }

  console.log("✅ User authenticated:", user.email);
  currentUser = user;

  const userBox = document.getElementById("userBox");
  const domainSelect = document.getElementById("domainSelect");
  const mobileMenuLinks = document.getElementById("mobileMenuLinks");
  const desktopMenu = document.getElementById("desktopMenu");
  const templateSelect = document.getElementById("templateSelect");
  const advancedInputs = document.getElementById("advancedInputs");
  const userEmail = document.getElementById("userEmail");
  const dropZoneText = document.getElementById("dropZoneText");
  const dropZoneSubtext = document.getElementById("dropZoneSubtext");
  const viewFilesBtn = document.getElementById("viewFilesBtn");

  // Show authenticated UI
  if (userBox) userBox.style.display = "block";
  if (userEmail) userEmail.textContent = user.email;
  if (domainSelect) domainSelect.style.display = "block";
  if (templateSelect) templateSelect.style.display = "block";
  if (advancedInputs) advancedInputs.style.display = "flex";
  if (dropZoneText) dropZoneText.textContent = "Tarik & letakkan file di sini";
  if (dropZoneSubtext) dropZoneSubtext.textContent = "atau klik untuk memilih berkas";
  if (viewFilesBtn) viewFilesBtn.style.display = "inline-flex";

  let userPlan = "free";
  let userRole = "";
  let isExpired = false;

    try {
    const userRef = ref(db, "users/" + user.uid);
    const userSnap = await get(userRef);
    
    if (userSnap.exists()) {
      const userData = userSnap.val();
      userPlan = userData.plan || "free";
      userRole = userData.role || "";
      isExpired = userData.expiredAt && Date.now() > userData.expiredAt;
      console.log("✅ User data loaded:", { userPlan, userRole });
    } else {
      // 🔥 KEPASTIAN: Jika data tidak ditemukan di node users, sistem akan langsung membuatnya!
      console.log("⚠️ Data user tidak ditemukan. Membuat data baru di Realtime Database...");
      await update(userRef, {
        uid: user.uid,
        email: user.email || "",
        plan: "free",
        role: "user",
        created: Date.now()
      });
      console.log("✅ Data user berhasil disinkronkan dan dibuat di node users!");
      userPlan = "free"; 
      userRole = "user";
    }
  } catch (err) {
    console.error("❌ Error loading/creating user data:", err);
  }


  loadDomains(userPlan, isExpired, userRole);

  const adsBox = document.querySelector(".adsBox");
  const isPremium = userPlan && (userPlan.includes("premium") || userPlan.includes("admin")) && !isExpired;

  if (adsBox) {
    adsBox.style.display = isPremium ? "none" : "block";
  }

  const premiumTemplates = ["v1dzy", "template_v2", "slicedrive", "template_v5"];
  if (templateSelect) {
    Array.from(templateSelect.options).forEach((opt) => {
      if (premiumTemplates.includes(opt.value)) {
        if (!isPremium) {
          opt.disabled = true;
          if (!opt.textContent.includes("🔒")) {
            opt.textContent = `🔒 ${opt.textContent} (Premium Only)`;
          }
          opt.style.color = "#666";
        } else {
          opt.disabled = false;
          opt.textContent = opt.textContent.replace("🔒 ", "").replace(" (Premium Only)", "");
          opt.style.color = "";
        }
      }
    });
  }

  if (mobileMenuLinks) {
    mobileMenuLinks.innerHTML = `
      <a href="/blog">Blog</a>
      <a href="#" onclick="openBiolink()">Biolink</a>
      <a href="/dashboard.html">Dashboard</a>
      <a href="/pricing.html">Premium</a>
      <a href="#" class="authBtn" onclick="logoutUser()">Logout</a>
    `;
  }
  if (desktopMenu) {
    desktopMenu.innerHTML = `
      <div class="navLinks">
        <a href="/blog">Blog</a>
        <a href="#" onclick="openBiolink()">Biolink</a>
        <a href="/dashboard.html">Dashboard</a>
        <a href="/pricing.html">Premium</a>
        <a href="#" class="authBtn" onclick="logoutUser()">Logout</a>
      </div>
    `;
  }
});

/* ===========================
   TEMPLATE DISPLAY TOGGLE
=========================== */
window.toggleFrontTemplate = function () {
  const templateSelect = document.getElementById("templateSelect");
  if (!templateSelect) return;
  const temp = templateSelect.value;

  const directInput = document.getElementById("urlInput");
  const v1Video = document.getElementById("videoUrlInput");
  const v1Button = document.getElementById("buttonUrlInput");
  const v2Video = document.getElementById("videoUrlInputV2");
  const v2Button = document.getElementById("buttonUrlInputV2");
  const v2Redirect = document.getElementById("redirectUrlInputV2");
  const v5Btn1 = document.getElementById("btn1InputV5");
  const v5Btn2 = document.getElementById("btn2InputV5");
  const v5Btn3 = document.getElementById("btn3InputV5");
  const sliceVideos = document.getElementById("videoUrlsInput");
  const sliceButton = document.getElementById("buttonUrlInputSlice");
  const sliceAuto = document.getElementById("autoRedirectUrlInputSlice");
  const v4Main = document.getElementById("mainUrlInputV4");
  const v4Second = document.getElementById("secondUrlInputV4");

  const allFields = [
    directInput, v1Video, v1Button, v2Video, v2Button, v2Redirect,
    sliceVideos, sliceButton, sliceAuto, v4Main, v4Second, v5Btn1, v5Btn2, v5Btn3
  ];

  allFields.forEach((el) => {
    if (el) el.style.display = "none";
  });

  if (temp === "") {
    if (directInput) directInput.style.display = "block";
    return;
  }
  if (temp === "v1dzy") {
    if (v1Video) v1Video.style.display = "block";
    if (v1Button) v1Button.style.display = "block";
  } else if (temp === "template_v2") {
    if (v2Video) v2Video.style.display = "block";
    if (v2Button) v2Button.style.display = "block";
    if (v2Redirect) v2Redirect.style.display = "block";
  } else if (temp === "slicedrive") {
    if (sliceVideos) sliceVideos.style.display = "block";
    if (sliceButton) sliceButton.style.display = "block";
    if (sliceAuto) sliceAuto.style.display = "block";
  } else if (temp === "template_v4") {
    if (v4Main) v4Main.style.display = "block";
    if (v4Second) v4Second.style.display = "block";
  } else if (temp === "template_v5") {
    if (v5Btn1) v5Btn1.style.display = "block";
    if (v5Btn2) v5Btn2.style.display = "block";
    if (v5Btn3) v5Btn3.style.display = "block";
  }
};

/* ===========================
   COPY TO CLIPBOARD
=========================== */
window.copyToClipboard = async function () {
  const shortLink = document.getElementById("shortLink");
  if (!shortLink) return;
  const shortLinkText = shortLink.textContent;
  if (!shortLinkText) return;

  try {
    await navigator.clipboard.writeText(shortLinkText);
    showToast("Copied");
  } catch (err) {
    showToast("Copy failed", "error");
  }
};

/* ===========================
   MEDIA UPLOADER
=========================== */
window.uploadMedia = async function () {
  const fileInput = document.getElementById("mediaFile");
  const file = fileInput ? fileInput.files[0] : null;

  if (!file) {
    showToast("Pilih atau drag file terlebih dahulu", "error");
    return;
  }

  const loadingStatus = document.getElementById("loadingStatus");
  const uploadResult = document.getElementById("uploadResult");

  try {
    if (loadingStatus) loadingStatus.style.display = "flex";
    if (uploadResult) uploadResult.innerHTML = "";

    const user = auth.currentUser;
    if (!user) {
      showToast("Login required", "error");
      return;
    }

    const token = await user.getIdToken();

    const formData = new FormData();
    formData.append("file", file);

    const response = await fetch("https://cdn.dyshort.pro", {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}` },
      body: formData
    });

    const data = await response.json();

    if (!data.success) {
      showToast(data.error || "Gagal mengunggah berkas", "error");
      return;
    }

    if (uploadResult) {
      uploadResult.innerHTML = `
        <div class="resultBox" style="margin-top: 15px; text-align: left;">
          <input value="${data.url}" readonly style="width:100%; padding:12px; background:#141414; border:1px solid #222; color:#fff; border-radius:5px; margin-bottom:8px; outline:none; font-size:13px;">
          <button class="copyBtn" onclick="copyToClipboardText('${data.url}')" style="width:100%; padding:12px; border-radius:5px; font-weight:800; border:none; cursor:pointer; background: #00ff99; color: #000; transition: transform 0.1s ease;">
            Copy Link
          </button>
          <div style="margin-top: 12px; text-align: center;">
            <a href="/media.html" style="color: #00ff99; text-decoration: underline; font-size: 12px; font-weight: 700;">Lihat Selengkapnya →</a>
          </div>
        </div>`;
    }

    showToast("Upload success");

  } catch (err) {
    console.error(err);
    showToast(err.message, "error");
  } finally {
    if (loadingStatus) loadingStatus.style.display = "none";
    if (fileInput) fileInput.value = "";
  }
};

window.copyToClipboardText = function (text) {
  navigator.clipboard.writeText(text);
  showToast("Copied to clipboard");
};

/* ===========================
   DRAG AND DROP
=========================== */
const dropZone = document.getElementById("dropZone");
const fileInput = document.getElementById("mediaFile");

if (dropZone && fileInput) {
  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("dragover");
  });

  ["dragleave", "drop"].forEach(eventName => {
    dropZone.addEventListener(eventName, () => dropZone.classList.remove("dragover"));
  });

  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    if (!currentUser) {
      showToast("Silakan login terlebih dahulu untuk mengunggah media.", "error");
      return;
    }
    const files = e.dataTransfer.files;
    if (files.length) {
      fileInput.files = files;
      window.uploadMedia();
    }
  });

  fileInput.addEventListener("change", () => {
    if (fileInput.files.length) {
      window.uploadMedia();
    }
  });
}

/* ===========================
   DOMAIN SEARCH
=========================== */
window.searchFromHome = function () {
  const inputElement = document.getElementById('homeDomainInput');
  if (!inputElement) return;
  const domainValue = inputElement.value.trim();

  if (!domainValue) {
    showToast('Silakan masukkan nama domain terlebih dahulu!', 'error');
    inputElement.focus();
    return;
  }

  const cleanDomain = domainValue.replace(/^https?:\/\//i, '').replace(/\/$/, '');
  const affiliateUrl = `https://my.domainesia.com/ref.php?u=27118&url=domain/&search=${encodeURIComponent(cleanDomain)}`;

  window.open(affiliateUrl, '_blank');
};

document.addEventListener('DOMContentLoaded', () => {
  const inputElement = document.getElementById('homeDomainInput');
  if (inputElement) {
    inputElement.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        window.searchFromHome();
      }
    });
  }
});

/* ===========================
   ACCORDION
=========================== */
window.toggleAccordion = function (element) {
  const parent = element.parentElement;
  const isActive = parent.classList.contains('active');

  document.querySelectorAll('.accordion-item').forEach(item => {
    item.classList.remove('active');
  });

  if (!isActive) {
    parent.classList.add('active');
  }
};
