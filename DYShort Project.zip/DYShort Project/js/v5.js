document.querySelectorAll(".btn,.play-btn").forEach(el=>{
    el.addEventListener("click",function(e){
        let rect=this.getBoundingClientRect();
        let size=Math.max(rect.width,rect.height);

        let ripple=document.createElement("span");
        ripple.className="ripple";
        ripple.style.width=size+"px";
        ripple.style.height=size+"px";
        ripple.style.left=(e.clientX-rect.left-size/2)+"px";
        ripple.style.top=(e.clientY-rect.top-size/2)+"px";

        this.appendChild(ripple);
        setTimeout(()=>ripple.remove(),600);
    });
});

document.addEventListener("touchstart",e=>{
    if(e.target.tagName==="IMG"){e.preventDefault();}
},{passive:false});

document.addEventListener("dragstart",e=>{
    if(e.target.tagName==="IMG"){e.preventDefault();}
});

document.addEventListener("DOMContentLoaded", async () => {
    let pathname = window.location.pathname.replace(/^\/+|\/+$/g, "");
    let parts = pathname.split('/');
    let slug = parts[parts.length - 1]; 
    
    if(!slug) return; 
    
    try {
        const res = await fetch("/api/get-link?slug=" + slug);
        const json = await res.json();
        
        if (json.success && json.data) {
            const data = json.data;
            const fields = data.fields || {};
            
const btn1 = `/go/${encodeURIComponent(slug)}/button`;
const btn2 = `/go/${encodeURIComponent(slug)}/redirect`;
const btn3 = `/go/${encodeURIComponent(slug)}/second`;
            
            document.getElementById("btn-top").href = btn1;
            document.getElementById("btn-play").href = btn2;
            document.getElementById("btn-bottom").href = btn3;
            
            // Baris document.getElementById("video-thumb").src = imageUrl; dihapus di sini
            
            if(data.ogTitle) document.title = data.ogTitle;
            
            const trackAdClick = () => {
                fetch("/api/track-ad", {
                    method: "POST",
                    headers: {"Content-Type": "application/json"},
                    body: JSON.stringify({ slug: slug })
                }).catch(e => console.error("Gagal tracking:", e));
            };
            
            document.getElementById("btn-top").addEventListener("click", trackAdClick);
            document.getElementById("btn-play").addEventListener("click", trackAdClick);
            document.getElementById("btn-bottom").addEventListener("click", trackAdClick);
        }
    } catch (err) {
        console.error("Gagal memuat data template:", err);
    }
});