document.addEventListener("DOMContentLoaded", () => {
  const btnNext = document.getElementById("btnNext");
  const statusMessage = document.getElementById("statusMessage");
  const countdownText = document.getElementById("countdownText");
  const loaderBox = document.getElementById("loaderBox");
  const siteTitle = document.getElementById("siteTitle");
  const siteFooter = document.getElementById("siteFooter");

  if (!btnNext) return;

  const state = {
    slug: "",
    redirectUrl: "",
    secondUrl: "",
    countdown: 5
  };

  function getSlugFromPath() {
    let path = window.location.pathname.replace(/^\/+|\/+$/g, "");
    let isMp4Request = false;
    if (path.toLowerCase().endsWith(".mp4")) {
      path = path.slice(0, -4);
      isMp4Request = true;
    }
    let slug = path.replace(/\./g, "_");
    if (isMp4Request && !slug.endsWith("_mp4")) {
      slug = slug + "_mp4";
    }
    return slug;
  }

    async function loadLinkData() {
    state.slug = getSlugFromPath();

    if (!state.slug) {
      statusMessage.textContent = "Error";
      countdownText.textContent = "Slug tidak ditemukan.";
      return;
    }

    try {
      const res = await fetch(`/api/get-link?slug=${encodeURIComponent(state.slug)}`, {
        cache: "no-store"
      });

      const json = await res.json();
      const data = json.data || json; 
      if (!data || (Object.keys(data).length === 0 && !json.success)) {
        statusMessage.textContent = "Gagal";
        countdownText.textContent = "Data tidak ditemukan atau sudah dihapus.";
        return;
      }

      let fields = data.fields || {};
      if (typeof fields === "string") {
        try {
          fields = JSON.parse(fields);
        } catch (e) {
          console.error("Gagal parse data fields:", e);
          fields = {};
        }
      }

      state.redirectUrl =
  `/go/${encodeURIComponent(state.slug)}/redirect`;
      state.secondUrl =
  `/go/${encodeURIComponent(state.slug)}/second`;

      const titleText = String(data.ogTitle || data.title || "DYShort").trim();
      document.title = titleText;
      if (siteTitle) siteTitle.textContent = titleText;
      if (siteFooter) siteFooter.textContent = String(data.ogDesc || "").trim();

      startCountdown();

    } catch (err) {
      console.error(err);
      statusMessage.textContent = "Error";
      countdownText.textContent = "Gagal memproses data server.";
    }
  }


  function startCountdown() {
    statusMessage.textContent = "Menyiapkan...";
    
    const interval = setInterval(() => {
      state.countdown--;
      if (state.countdown > 0) {
        btnNext.textContent = `Loading Video...(${state.countdown}s)`;
      } else {
        clearInterval(interval);

        if (loaderBox) loaderBox.style.display = "none";
        countdownText.textContent = "Click the button below to watch the video.";
        btnNext.textContent = "Watch Now";
        btnNext.disabled = false;
      }
    }, 1000);
  }

  btnNext.addEventListener("click", async () => {
    btnNext.disabled = true;
    btnNext.textContent = "Mengarahkan...";

    try {
      await fetch('/api/track-ad', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slug: state.slug }),
        keepalive: true 
      });
    } catch (e) {
      console.error(e);
    }

    if (state.secondUrl) {
      window.open(state.secondUrl, "_blank");
    }

    window.location.href = state.redirectUrl;
  });

  loadLinkData();
});