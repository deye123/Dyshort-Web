import app from "/js/firebase-init.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const auth = getAuth(app);

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeJs(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/\\/g, "\\\\")
    .replace(/'/g, "\\'")
    .replace(/\r/g, " ")
    .replace(/\n/g, " ");
}

function formatDate(ts) {
  if (!ts) return "";
  try {
    return new Intl.DateTimeFormat("id-ID", {
      dateStyle: "medium",
      timeStyle: "short"
    }).format(new Date(ts));
  } catch {
    return new Date(ts).toLocaleString("id-ID");
  }
}

function isImageFile(item) {
  if (!item) return false;
  if (item.type === "image") return true;
  const name = item.file || "";
  return /\.(png|jpg|jpeg|webp|gif)$/i.test(name);
}

let allUploads = [];
let currentPage = 1;
const perPage = 6;

function showToast(text, type = "success") {
  const toast = document.getElementById("toast");
  if (!toast) return;
  toast.className = type;
  toast.innerText = text;
  toast.style.display = "block";
  setTimeout(() => {
    toast.style.display = "none";
  }, 3000);
}

onAuthStateChanged(auth, (user) => {
  if (!user) {
    alert("Login required");
    window.location.href = "/";
    return;
  }

  loadUploadHistory(user);
});

window.copyLink = async function (url) {
  try {
    await navigator.clipboard.writeText(url);
    showToast("Copied to clipboard");
  } catch {
    showToast("Gagal menyalin", "error");
  }
};

window.deleteUpload = async function (fileName) {
  const confirmDelete = confirm("Harap hapus media yang tidak digunakan agar storage tetap hemat.");
  if (!confirmDelete) return;

  const user = auth.currentUser;
  if (!user) return showToast("Login required", "error");

  try {
    showToast("Deleting media...", "info");

    const token = await user.getIdToken();
    const response = await fetch("https://cdn.dyshort.pro", {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({ file: fileName })
    });

    const result = await response.json();
    if (!result.success) throw new Error(result.error || "Failed to delete");

    allUploads = allUploads.filter(item => item.file !== fileName);
    renderUploads();
    showToast("Media deleted");
  } catch (err) {
    console.error(err);
    showToast(err.message, "error");
  }
};

async function loadUploadHistory(user) {
  if (!user) return;
  try {
    // SINKRONISASI: Tambahkan _t (cache-buster) dan cache: "no-store"
    const token = await user.getIdToken();
    const apiUrl = `https://cdn.dyshort.pro?uid=${user.uid}&_t=${Date.now()}`;
    const response = await fetch(apiUrl, {
      cache: "no-store",
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (!response.ok) return console.error("Gagal terhubung ke worker, status:", response.status);

    const result = await response.json();
    if (!result.success) return showToast(result.error || "Gagal memuat data", "error");

    const rawUploads = result.uploads || [];
    if (rawUploads && typeof rawUploads === 'object' && !Array.isArray(rawUploads)) {
      allUploads = Object.values(rawUploads);
    } else {
      allUploads = rawUploads;
    }

    renderUploads();
  } catch (err) {
    console.error("Error saat fetch history:", err);
  }
}

function renderUploads() {
  const box = document.getElementById("uploadHistory");
  const pagWrap = document.getElementById("paginationWrap");
  const pageInfo = document.getElementById("pageInfo");
  if (!box) return;

  box.innerHTML = "";

  const validUploads = allUploads.filter(item => item && (item.url || item.file));

  if (validUploads.length === 0) {
    box.innerHTML = `<div class="emptyState">🗄️ Belum ada file yang diunggah</div>`;
    if (pagWrap) pagWrap.style.display = "none";
    return;
  }

  const totalPages = Math.ceil(validUploads.length / perPage);
  if (currentPage > totalPages) currentPage = totalPages || 1;
  if (currentPage < 1) currentPage = 1;

  const start = (currentPage - 1) * perPage;
  const end = start + perPage;
  const currentData = validUploads.slice(start, end);

  currentData.forEach((item) => {
    try {
      const fileStr = item.file || "";
      const urlStr = item.url || (fileStr ? "https://cdn.dyshort.pro/" + fileStr : "URL Tidak Valid");
      const safeId = fileStr.replace(/[^a-zA-Z0-9]/g, "_") || Math.random().toString(36).substring(7);

      const previewHtml = isImageFile(item)
        ? `<img src="${escapeHtml(urlStr)}" alt="" loading="lazy">`
        : `<video src="${escapeHtml(urlStr)}" controls controlsList="nodownload noplaybackrate" disablePictureInPicture></video>`;

      box.innerHTML += `
        <div class="media-card">
          <div class="media-preview">
            <div id="preview-${safeId}" style="display:none; width:100%; height:100%;">
              ${previewHtml}
            </div>
            <div id="thumb-${safeId}" class="thumbIcon" style="display:flex; align-items:center; justify-content:center; width:100%; height:100%;">
              ${isImageFile(item) ? "🖼️" : "🎥"}
            </div>
          </div>
          
          <div style="margin-top: 12px; width: 100%;">
            <input type="text" value="${escapeHtml(urlStr)}" readonly style="width:100%; padding:10px; background:#0a0a0a; border:1px solid rgba(0,255,153,.45); color:#00ff99; border-radius:8px; outline:none; font-size:12px; font-weight:700; text-align:center;">
          </div>

          <div class="media-actions" style="margin-top: 10px;">
            <button class="copyBtn" onclick="copyLink('${escapeJs(urlStr)}')">Copy</button>
            <button class="viewBtn" id="btn-${safeId}" onclick="togglePreviewState('${safeId}')">View</button>
            <button class="delBtn" onclick="deleteUpload('${escapeJs(fileStr)}')">Del</button>
          </div>
        </div>`;
    } catch (renderErr) {
      console.error("Gagal me-render item media:", renderErr);
    }
  });

  if (pagWrap) {
    if (totalPages > 1) {
      pagWrap.style.display = "flex";
      if (pageInfo) pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;
    } else {
      pagWrap.style.display = "none";
    }
  }
}

window.togglePreviewState = function (safeId) {
  const preview = document.getElementById("preview-" + safeId);
  const thumb = document.getElementById("thumb-" + safeId);
  const btn = document.getElementById("btn-" + safeId);

  if (preview && thumb && btn) {
    const hidden = preview.style.display === "none" || !preview.style.display;
    if (hidden) {
      preview.style.display = "block";
      thumb.style.display = "none";
      btn.innerText = "Close";
    } else {
      preview.style.display = "none";
      thumb.style.display = "flex";
      btn.innerText = "View";
    }
  }
};

window.prevPage = function () {
  if (currentPage > 1) {
    currentPage--;
    renderUploads();
  }
};

window.nextPage = function () {
  const totalPages = Math.ceil(allUploads.length / perPage);
  if (currentPage < totalPages) {
    currentPage++;
    renderUploads();
  }
};

window.uploadMedia = async function () {
  const fileInput = document.getElementById("mediaFile");
  const file = fileInput?.files?.[0];

  if (!file) {
    showToast("Select or drop file first", "error");
    return;
  }

  const loadingStatus = document.getElementById("loadingStatus");
  const uploadResult = document.getElementById("uploadResult");

  try {
    if (loadingStatus) loadingStatus.style.display = "flex";
    if (uploadResult) uploadResult.innerHTML = "";

    const user = auth.currentUser;
    if (!user) return showToast("Login required", "error");

    const token = await user.getIdToken();

    const formData = new FormData();
    formData.append("file", file);
    formData.append("mode", "media");

    const response = await fetch("https://cdn.dyshort.pro", {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}` },
      body: formData
    });

    const data = await response.json();
    if (!data.success) {
      showToast(data.error || "Upload failed", "error");
      return;
    }

    if (uploadResult) {
      uploadResult.innerHTML = `
        <div class="resultBox" style="margin-top: 15px;">
          <input value="${escapeHtml(data.url)}" readonly style="width:100%; padding:12px; background:#0a0a0a; border:1px solid #262626; color:#00ff99; border-radius:5px; margin-bottom:8px; outline:none; font-size:13px; font-weight:700;">
          <button class="copyBtn" onclick="copyLink('${escapeJs(data.url)}')" style="width:100%; padding:12px; margin-top:8px; font-weight:900; border-radius:10px; border:none; cursor:pointer;">
            Copy Direct Link
          </button>
        </div>`;
    }

    const newFileName = data.file || data.url.split('/').pop();
    
    // INSTANT UI UPDATE
    allUploads.unshift({
      file: newFileName,
      url: data.url,
      type: data.type || (file.type.startsWith("video/") ? "video" : "image"),
      created: Date.now()
    });

    currentPage = 1;
    renderUploads();

    showToast("Upload success");
  } catch (err) {
    console.error(err);
    showToast(err.message, "error");
  } finally {
    if (loadingStatus) loadingStatus.style.display = "none";
    if (fileInput) fileInput.value = "";
  }
};

const dropZone = document.getElementById("dropZone");
const fileInput = document.getElementById("mediaFile");

if (dropZone && fileInput) {
  dropZone.addEventListener("click", () => fileInput.click());
  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("dragover");
  });

  ["dragleave", "drop"].forEach(eventName => {
    dropZone.addEventListener(eventName, () => dropZone.classList.remove("dragover"));
  });

  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files.length) {
      fileInput.files = files;
      window.uploadMedia();
    }
  });

  fileInput.addEventListener("change", () => {
    if (fileInput.files.length) {
      window.uploadMedia();
    }
  });
}