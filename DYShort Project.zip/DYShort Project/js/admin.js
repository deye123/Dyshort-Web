import { 
  getAuth, 
  signInWithEmailAndPassword, 
  onAuthStateChanged, 
  signOut 
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';

import { 
  getDatabase, 
  ref, 
  update, 
  push, 
  get, 
  onValue, 
  remove,
  set 
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js';

import firebaseApp from '/js/firebase-init.js';

const auth = getAuth(firebaseApp);
const db = getDatabase(firebaseApp);

// 🔥 FLAG PROTEKSI: Mencegah duplikasi listener realtime
let isListenersInitialized = false;

// --- GLOBAL NOTIFIKASI TOAST ---
function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  const toastText = document.getElementById('toastText');
  if (toast && toastText) {
    toastText.innerText = message;
    toast.style.display = 'block';
    toast.style.borderColor = (type === 'success') ? '#00ff99' : '#ff4444';
    setTimeout(() => { toast.style.display = 'none'; }, 3000);
  } else {
    alert(message);
  }
}

// --- SYSTEM TAB NAVIGATION SWITCHER ---
const switchTab = (tabName) => {
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
  
  const targetContent = document.getElementById(`tab-${tabName}`);
  if (targetContent) targetContent.classList.add('active');
  
  const targetBtn = Array.from(document.querySelectorAll('.tab-btn')).find(btn => 
    btn.getAttribute('onclick') && btn.getAttribute('onclick').includes(`'${tabName}'`)
  );
  if (targetBtn) targetBtn.classList.add('active');
};

// --- MONITOR STATUS LOGIN ADMINISTRATOR ---
onAuthStateChanged(auth, async (user) => {
  const loginSection = document.getElementById('loginSection');
  const adminSection = document.getElementById('adminSection');
  const adminStatusText = document.getElementById('adminStatusText');
  
  if (user) {
    try {
      const userSnap = await get(ref(db, 'users/' + user.uid));
      if (userSnap.exists()) {
        const userData = userSnap.val();
        if (userData.role === 'admin' || userData.isAdmin === true || userData.role === 'Administrator') {
          if (loginSection) loginSection.style.display = 'none';
          if (adminSection) adminSection.style.display = 'block';
          if (adminStatusText) adminStatusText.innerText = `Masuk sebagai: ${user.email}`;
          
          initLiveListeners(); // Panggil engine live listener
          return;
        }
      }
      showToast('Akses ditolak! Anda bukan Administrator.', 'error');
      await signOut(auth);
    } catch (error) {
      console.error(error);
      await signOut(auth);
    }
  } else {
    if (loginSection) loginSection.style.display = 'flex';
    if (adminSection) adminSection.style.display = 'none';
    isListenersInitialized = false; // Reset flag ketika logout
  }
});

// --- CORE ACTION: LOGIN / LOGOUT ---
const loginAdmin = async () => {
  const email = document.getElementById('adminEmail').value.trim();
  const password = document.getElementById('adminPassword').value;
  const loginBtn = document.getElementById('loginBtn');
  
  if (!email || !password) {
    showToast('Harap isi semua kolom email & password!', 'error');
    return;
  }
  try {
    if (loginBtn) { loginBtn.disabled = true; loginBtn.innerText = 'Memproses...'; }
    await signInWithEmailAndPassword(auth, email, password);
    showToast('Login Berhasil!', 'success');
  } catch (error) {
    showToast('Gagal masuk: ' + error.message, 'error');
  } finally {
    if (loginBtn) { loginBtn.disabled = false; loginBtn.innerText = 'Masuk Ke Panel'; }
  }
};

const logoutAdmin = async () => {
  try {
    await signOut(auth);
    showToast('Berhasil keluar sistem.', 'success');
  } catch (error) {
    console.error(error);
  }
};

// --- CORE LIVE ENGINE: MEMBACA DAN ME-RENDER DAFTAR REALTIME ---
function initLiveListeners() {
  // 🔥 Jika listener sudah terpasang sebelumnya, hentikan eksekusi duplikat
  if (isListenersInitialized) return;
  isListenersInitialized = true;

  console.log("📡 Mengaktifkan Realtime Database Listeners...");

  // 1. Ambil & Hitung Statistik Utama + render Tabel Pengguna
  onValue(ref(db, 'users'), (snapshot) => {
    const userTableBody = document.getElementById('userTableBody');
    const statTotalUsers = document.getElementById('statTotalUsers');
    const statPremiumUsers = document.getElementById('statPremiumUsers');
    
    if (snapshot.exists()) {
      const users = snapshot.val();
      let total = 0; 
      let premiumCount = 0;
      let htmlContent = ''; 
      
      Object.keys(users).forEach(uid => {
        const u = users[uid];
        if (!u || typeof u !== 'object') return; 
        
        total++;
        const isPremium = u.plan === 'premium';
        const isBanned = u.status === 'banned';
        
        if (isPremium && !isBanned) premiumCount++;
        const expiry = u.expiredAt ? new Date(u.expiredAt).toLocaleDateString('id-ID') : '-';
        
        htmlContent += `
          <tr>
            <td>
              <div style="font-weight:700; color:${isBanned ? '#ff4444' : '#fff'};">${u.email || 'No Email'} ${isBanned ? '(BANNED)' : ''}</div>
              <div style="font-size:10px; color:#555;">UID: ${uid}</div>
            </td>
            <td>
              <span style="background:${isPremium ? '#00ff9922' : '#222'}; color:${isPremium ? '#00ff99' : '#888'}; padding:4px 8px; border-radius:4px; font-size:11px; font-weight:700;">
                ${(u.plan || 'free').toUpperCase()}
              </span>
            </td>
            <td>${expiry}</td>
            <td style="display:flex; gap:8px;">
              <button onclick="toggleSuspendUser('${uid}', ${isBanned})" class="btn-dark" style="padding:6px 12px; font-size:11px; border-color:${isBanned ? '#00ff99' : '#ffaa00'}; color:${isBanned ? '#00ff99' : '#ffaa00'};">
                ${isBanned ? 'PULIHKAN' : 'SUSPEND'}
              </button>
              <button onclick="deleteUser('${uid}')" class="btn-danger">HAPUS</button>
            </td>
          </tr>
        `;
      });
      
      if (userTableBody) userTableBody.innerHTML = htmlContent;
      if (statTotalUsers) statTotalUsers.innerText = total;
      if (statPremiumUsers) statPremiumUsers.innerText = premiumCount;
      
    } else {
      if (userTableBody) userTableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:#444;">Belum ada data pengguna.</td></tr>';
      if (statTotalUsers) statTotalUsers.innerText = '0';
      if (statPremiumUsers) statPremiumUsers.innerText = '0';
    }
  });

  // 2. Ambil Jumlah & List Domain Aktif (🔥 FIX OPTIMASI LOOP RENDER)
  onValue(ref(db, 'domains'), (snapshot) => {
    const statTotalDomains = document.getElementById('statTotalDomains');
    const domainListBody = document.getElementById('domainListBody');
    
    if (snapshot.exists()) {
      const data = snapshot.val();
      if (statTotalDomains) statTotalDomains.innerText = Object.keys(data).length;
      if (domainListBody) {
        let htmlContent = '';
        Object.keys(data).forEach(key => {
          htmlContent += `
            <tr>
              <td>${data[key].name}</td>
              <td><button onclick="deleteDomain('${key}')" class="btn-danger">Hapus</button></td>
            </tr>
          `;
        });
        domainListBody.innerHTML = htmlContent;
      }
    } else {
      if (statTotalDomains) statTotalDomains.innerText = '0';
      if (domainListBody) domainListBody.innerHTML = '<tr><td colspan="2" style="text-align:center; color:#444;">Belum ada domain.</td></tr>';
    }
  });

  // 3. Ambil Antrean Request Premium (🔥 FIX OPTIMASI LOOP RENDER)
  onValue(ref(db, 'payment_requests'), (snapshot) => {
    const requestTableBody = document.getElementById('requestTableBody');
    if (requestTableBody) {
      if (snapshot.exists()) {
        const requests = snapshot.val();
        let htmlContent = '';
        Object.keys(requests).forEach(key => {
          const req = requests[key];
          htmlContent += `
            <tr>
              <td>
                <div style="font-weight:700;">${req.email || 'No Email'}</div>
                <div style="font-size:10px; color:#555;">UID: ${req.uid || key}</div>
              </td>
              <td><span style="background:#0099ff22; color:#0099ff; padding:4px 8px; border-radius:4px; font-weight:700;">${req.plan || 'Premium'}</span></td>
              <td>Menunggu Konfirmasi</td>
              <td style="display:flex; gap:8px;">
                <button onclick="processRequest('${req.uid || key}', '${req.plan || 'Monthly'}', 'approve')" class="btn-green" style="padding:6px 12px; font-size:11px;">APPROVE</button>
                <button onclick="processRequest('${req.uid || key}', '${req.plan || 'Monthly'}', 'reject')" class="btn-danger" style="padding:6px 12px; font-size:11px;">REJECT</button>
              </td>
            </tr>
          `;
        });
        requestTableBody.innerHTML = htmlContent;
      } else {
        requestTableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:20px; color:#444;">Tidak ada antrean baru...</td></tr>';
      }
    }
  });

  // 4. Ambil Daftar Landing Page (🔥 FIX OPTIMASI LOOP RENDER)
  onValue(ref(db, 'landing_pages'), (snapshot) => {
    const lpListBody = document.getElementById('lpListBody');
    if (lpListBody) {
      if (snapshot.exists()) {
        const data = snapshot.val();
        let htmlContent = '';
        Object.keys(data).forEach(key => {
          htmlContent += `
            <tr>
              <td>${data[key].title} (${data[key].preview})</td>
              <td><button onclick="deleteLP('${key}')" class="btn-danger">Hapus</button></td>
            </tr>
          `;
        });
        lpListBody.innerHTML = htmlContent;
      } else {
        lpListBody.innerHTML = '<tr><td colspan="2" style="text-align:center; color:#444;">Belum ada Landing Page.</td></tr>';
      }
    }
  });

  // 5. Sinkronisasi Data Setelan Iklan Monetag
  onValue(ref(db, 'settings/monetize'), (snapshot) => {
    if (snapshot.exists()) {
      const config = snapshot.val();
      if (document.getElementById('adEnabled')) document.getElementById('adEnabled').checked = !!config.enabled;
      if (document.getElementById('adDirectLink')) document.getElementById('adDirectLink').value = config.directLink || '';
      if (document.getElementById('adInterval')) document.getElementById('adInterval').value = config.interval || 30;
    }
  });
}

// --- FUNGSI SUSPEND USER ---
const toggleSuspendUser = async (uid, isCurrentlyBanned) => {
  const confirmMsg = isCurrentlyBanned 
    ? 'Pulihkan pengguna ini? Mereka akan bisa mengakses sistem lagi.' 
    : 'Suspend pengguna ini? Semua akses API dan tautan mereka akan diblokir.';
    
  if (confirm(confirmMsg)) {
    try {
      await update(ref(db, 'users/' + uid), { 
        status: isCurrentlyBanned ? 'active' : 'banned' 
      });
      showToast(`Pengguna berhasil di-${isCurrentlyBanned ? 'pulihkan' : 'suspend'}.`, 'success');
    } catch (e) {
      showToast(e.message, 'error');
    }
  }
};

// --- AKSI PENGELOLA DATA (PROSES & HAPUS) ---
const processRequest = async (uid, plan, action) => {
  try {
    if (action === 'approve') {
      const days = plan.toLowerCase().includes('yearly') ? 365 : 30;
      const expiredAt = Date.now() + (days * 24 * 60 * 60 * 1000);
      await update(ref(db, 'users/' + uid), { plan: 'premium', expiredAt: expiredAt });
      await remove(ref(db, 'payment_requests/' + uid));
      showToast('Permintaan berhasil disetujui!', 'success');
    } else {
      await remove(ref(db, 'payment_requests/' + uid));
      showToast('Permintaan ditolak.', 'error');
    }
  } catch (e) { showToast(e.message, 'error'); }
};

const upgradeUser = async () => {
  const targetUid = document.getElementById('targetUid').value.trim();
  const days = parseInt(document.getElementById('premiumDuration').value) || 30;
  if (!targetUid) return showToast('Harap masukkan target UID!', 'error');
  try {
    const expiredAt = Date.now() + (days * 24 * 60 * 60 * 1000);
    await update(ref(db, 'users/' + targetUid), { plan: 'premium', expiredAt: expiredAt });
    showToast('Sukses upgrade manual!', 'success');
    document.getElementById('targetUid').value = '';
  } catch (e) { showToast(e.message, 'error'); }
};

const saveLP = async () => {
  const title = document.getElementById('lpTitle').value.trim();
  const preview = document.getElementById('lpPreview').value.trim();
  if (!title || !preview) return showToast('Title dan Preview wajib diisi!', 'error');
  try {
    await push(ref(db, 'landing_pages'), {
      title, preview,
      desc: document.getElementById('lpDesc').value.trim(),
      image: document.getElementById('lpImage').value.trim(),
      price: document.getElementById('lpPrice').value.trim() || 'Free',
      category: document.getElementById('lpCategory').value.trim() || 'Bio Link'
    });
    showToast('Landing page berhasil ditambahkan.');
    document.querySelectorAll('#tab-assets input').forEach(i => i.value = '');
  } catch (e) { showToast(e.message, 'error'); }
};

const saveDomain = async () => {
  const name = document.getElementById('domainName').value.trim();
  const url = document.getElementById('domainUrl').value.trim();
  if (!name || !url) return showToast('Isi nama dan URL domain!', 'error');
  try {
    await push(ref(db, 'domains'), {
      name, url,
      premium: document.getElementById('premiumCheck').checked,
      ownerUid: document.getElementById('domainOwnerUid').value.trim() || null
    });
    showToast('Domain didaftarkan.');
    document.getElementById('domainName').value = '';
    document.getElementById('domainUrl').value = '';
    document.getElementById('domainOwnerUid').value = '';
  } catch (e) { showToast(e.message, 'error'); }
};

const saveSettings = async () => {
  try {
    await set(ref(db, 'settings/monetize'), {
      enabled: document.getElementById('adEnabled').checked,
      directLink: document.getElementById('adDirectLink').value.trim(),
      interval: parseInt(document.getElementById('adInterval').value) || 30
    });
    showToast('Konfigurasi monetisasi disimpan.');
  } catch (e) { showToast(e.message, 'error'); }
};

const deleteUser = async (uid) => { if (confirm('Hapus pengguna ini?')) remove(ref(db, 'users/' + uid)); };
const deleteLP = async (key) => { if (confirm('Hapus template ini?')) remove(ref(db, 'landing_pages/' + key)); };
const deleteDomain = async (key) => { if (confirm('Hapus domain ini?')) remove(ref(db, 'domains/' + key)); };

const purgeCloudflareCache = async () => {
  const btn = document.getElementById('btnPurgeCache');
  if (!btn) return;
  btn.disabled = true; btn.innerText = "Memproses...";
  try {
    const token = auth.currentUser ? await auth.currentUser.getIdToken() : '';
    const res = await fetch('/api/purge-cache', { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } });
    const data = await res.json().catch(() => ({}));

    if (res.ok && data.success) {
      // 🔥 Broadcast versi cache baru ke Firebase — setiap browser pengguna
      // yang sedang membuka situs (via cache-buster.js + sw.js) akan otomatis
      // menghapus seluruh cache lokal dan reload dengan file terbaru.
      await set(ref(db, 'settings/cacheVersion'), Date.now());
      showToast("Cache Cloudflare & cache browser semua pengguna berhasil dibersihkan.");
    } else {
      // Tampilkan alasan gagal yang sebenarnya, bukan pesan generik
      const detail = data?.message || data?.details?.errors?.[0]?.message || `HTTP ${res.status}`;
      throw new Error(detail);
    }
  } catch (err) {
    console.error("Purge cache error:", err);
    showToast("Gagal membersihkan cache: " + (err.message || 'Kesalahan tidak diketahui'), "error");
  }
  finally { btn.disabled = false; btn.innerText = "🔄 Purge All Edge Cache"; }
};

// --- BINDING SCOPE KE WINDOW OBJECT ---
window.loginAdmin = loginAdmin;
window.logoutAdmin = logoutAdmin;
window.switchTab = switchTab;
window.processRequest = processRequest;
window.upgradeUser = upgradeUser;
window.saveLP = saveLP;
window.deleteLP = deleteLP;
window.saveDomain = saveDomain;
window.deleteDomain = deleteDomain;
window.deleteUser = deleteUser;
window.saveSettings = saveSettings;
window.purgeCloudflareCache = purgeCloudflareCache;
window.toggleSuspendUser = toggleSuspendUser;