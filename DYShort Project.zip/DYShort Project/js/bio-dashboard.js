import app from "/js/firebase-init.js";

import {
  getDatabase,
  ref,
  set,
  get,
  remove,
  onValue
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

import {
  getAuth,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const db = getDatabase(app);
const auth = getAuth(app);

const DOMAIN_BARU = "https://waae.my.id";

let currentUser = null;
let avatarUrl = "";
let coverUrl = "";
let currentBio = null;

// --- DOM UTILITY HELPERS (Mencegah script crash jika elemen tidak ada di HTML) ---
const $ = (id) => document.getElementById(id);
const getVal = (id) => $(id) ? $(id).value : "";
const getChecked = (id) => $(id) ? $(id).checked : false;
const setVal = (id, val) => { if ($(id)) $(id).value = val; };
const setChecked = (id, state) => { if ($(id)) $(id).checked = state; };
const setText = (id, text) => { if ($(id)) $(id).innerText = text; };
const setHtml = (id, html) => { if ($(id)) $(id).innerHTML = html; };
const setSrc = (id, src) => { if ($(id)) $(id).src = src; };
const setDisplay = (id, mode) => { if ($(id)) $(id).style.display = mode; };

// Fungsi utilitas escape HTML untuk mencegah XSS & Broken Layout
function escapeHtml(str = "") {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function toast(text, type = "success") {
  const t = $("toast");
  if (!t) return;
  t.className = type;
  t.innerText = text;
  t.style.display = "block";

  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => {
    t.style.display = "none";
  }, 2500);
}

async function uploadImage(file) {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("uid", currentUser.uid); 

  const res = await fetch("https://cdn.dyshort.pro", {
    method: "POST",
    body: formData
  });

  const data = await res.json();
  if (!data.success) {
    throw new Error(data.error || "Upload failed");
  }
  return data.url;
}

function updateBioUrl() {
  const username = getVal("username").trim().toLowerCase();
  setVal("bioUrl", username ? DOMAIN_BARU + "/u/" + username : "");
}

window.copyBio = function () {
  const val = getVal("bioUrl");
  if (!val) {
    toast("No URL", "error");
    return;
  }
  navigator.clipboard.writeText(val);
  toast("Copied");
};

async function loadBioList() {
  if (!currentUser) return;

  const snap = await get(ref(db, "bios"));
  const bioListEl = $("bioList");
  if (!bioListEl) return;
  
  bioListEl.innerHTML = "";

  if (!snap.exists()) {
    bioListEl.innerHTML = `<div class="smallText">No bio created yet</div>`;
    return;
  }

  const data = snap.val();
  const arr = Object.values(data).filter(item => item && item.uid === currentUser.uid);

  if (!arr.length) {
    bioListEl.innerHTML = `<div class="smallText">No bio created yet</div>`;
    return;
  }

  arr.forEach((bio) => {
    bioListEl.innerHTML += `
      <div class="bioCard">
        <div class="bioCardTop">
          <div class="bioCardLeft">
            <div class="bioCardTitle">${escapeHtml(bio.name || bio.username)}</div>
            <div class="bioCardUrl">${DOMAIN_BARU}/u/${escapeHtml(bio.username)}</div>
          </div>
          <div class="bioCardActions">
            <button class="btnGhost" onclick="editBio('${escapeHtml(bio.username)}')">Edit</button>
            <button class="btnGhost" onclick="window.open('${DOMAIN_BARU}/u/${escapeHtml(bio.username)}','_blank')">Open</button>
            <button class="btnGhost" style="border-color:#ff4444;color:#ff4444;" onclick="deleteBioByUsername('${escapeHtml(bio.username)}')">Delete</button>
          </div>
        </div>
      </div>
    `;
  });
}

window.editBio = async function (username) {
  const snap = await get(ref(db, "bios/" + username));
  if (!snap.exists()) return;

  const found = snap.val();
  currentBio = found;

  // Menggunakan helper setVal agar aman dari elemen null
  setVal("username", found.username || "");
  setVal("displayName", found.name || "");
  setVal("bio", found.bio || "");
  setVal("theme", found.theme || "green");
  setVal("primaryColor", found.primaryColor || "");
  setChecked("verified", !!found.verified);
  setChecked("hideBranding", !!found.hideBranding);
  setVal("music", found.music || "");
  setVal("youtubeEmbed", found.youtubeEmbed || "");
  setVal("donate", found.donate || "");

  setVal("coverVideo", found.coverVideo || "");
  setVal("shareText", found.shareText || "");
  setVal("customCss", found.customCss || "");
  setVal("emailLabel", found.emailLabel || "");
  setVal("ogTitle", found.ogTitle || "");
  setVal("ogDesc", found.ogDesc || "");
  setVal("pinnedTitle", found.pinnedTitle || "");
  setVal("pinnedUrl", found.pinnedUrl || "");
  setVal("pinnedIcon", found.pinnedIcon || "");
  setChecked("passwordMode", !!found.passwordMode);
  setChecked("scheduleMode", !!found.scheduleMode);
  setChecked("allowComments", !!found.allowComments);
  setVal("bioPassword", found.bioPassword || "");
  setVal("activeFrom", found.activeFrom || "");
  setVal("activeUntil", found.activeUntil || "");

  avatarUrl = found.avatar || "";
  coverUrl = found.cover || "";

  setSrc("previewAvatar", avatarUrl || "https://i.ibb.co/2M7rtLk/user.png");
  setSrc("avatarPreviewMini", avatarUrl || "https://i.ibb.co/2M7rtLk/user.png");
  setSrc("coverPreviewMini", coverUrl || "");

  if ($("previewCover")) $("previewCover").style.backgroundImage = coverUrl ? `url('${coverUrl}')` : "";

  if ($("linksBox")) {
    $("linksBox").innerHTML = "";
    Object.values(found.links || {}).forEach((link) => addLink(link));
  }
  if ($("galleryBox")) {
    $("galleryBox").innerHTML = "";
    Object.values(found.gallery || {}).forEach((src) => addGalleryItem(src));
  }
  if ($("productsBox")) {
    $("productsBox").innerHTML = "";
    Object.values(found.products || {}).forEach((item) => addProductItem(item));
  }

  updateBioUrl();
  renderPreview();
  renderStats();
  toast("Bio loaded");
};

window.createNewBio = function () {
  currentBio = null;

  document.querySelectorAll("input, textarea").forEach((el) => {
    if (el.type !== "checkbox" && el.type !== "file") {
      el.value = "";
    }
  });

  document.querySelectorAll("input[type='checkbox']").forEach((el) => {
    el.checked = false;
  });

  setVal("theme", "green");
  setHtml("linksBox", "");
  setHtml("galleryBox", "");
  setHtml("productsBox", "");

  avatarUrl = "";
  coverUrl = "";

  setSrc("previewAvatar", "https://i.ibb.co/2M7rtLk/user.png");
  setSrc("avatarPreviewMini", "https://i.ibb.co/2M7rtLk/user.png");
  if ($("previewCover")) $("previewCover").style.backgroundImage = "";

  updateBioUrl();
  renderPreview();
  renderStats();
  toast("New bio form ready");
};

window.deleteBioByUsername = async function (username) {
  const ok = confirm("Delete bio @" + username + " ?");
  if (!ok) return;

  try {
    await remove(ref(db, "bios/" + username));
    toast("Bio deleted");
    await loadBioList();
    if (currentBio && currentBio.username === username) {
      createNewBio();
    }
  } catch (err) {
    console.error(err);
    toast("Delete failed", "error");
  }
};

function renderPreview() {
  setText("previewName", getVal("displayName") || "User");
  setText("previewBio", getVal("bio") || "Your bio here");
  setHtml("previewVerifiedWrap", getChecked("verified") ? `<span class="verified">✔ VERIFIED</span>` : "");

  const theme = getVal("theme") || "green";
  const primaryColor = getVal("primaryColor");
  
  document.body.classList.remove("blue", "purple", "orange");
  if (theme === "blue" || theme === "purple" || theme === "orange") {
    document.body.classList.add(theme);
  }

  if (primaryColor && /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(primaryColor)) {
    document.documentElement.style.setProperty("--primary", primaryColor);
  } else {
    const map = { green: "#00ff99", blue: "#00aaff", purple: "#bb66ff", orange: "#ff9f43" };
    document.documentElement.style.setProperty("--primary", map[theme] || "#00ff99");
  }

  const coverVideo = getVal("coverVideo");
  const previewCover = $("previewCover");
  if (previewCover) {
    if (coverVideo) {
      previewCover.innerHTML = `<video autoplay muted loop playsinline src="${escapeHtml(coverVideo)}"></video>`;
    } else {
      previewCover.innerHTML = "";
      previewCover.style.backgroundImage = coverUrl ? `url('${coverUrl}')` : "";
    }
  }

  const pinnedTitle = getVal("pinnedTitle");
  const pinnedUrl = getVal("pinnedUrl");
  const pinnedIcon = getVal("pinnedIcon") || "⭐";
  let pinnedHtml = "";
  if (pinnedTitle && pinnedUrl) {
    pinnedHtml = `
      <div class="pinned" style="margin-top:22px; background:rgba(0,255,153,.08); border:1px solid rgba(0,255,153,.18); padding:14px 16px; border-radius:16px; text-align:left;">
        <div class="sectionHead" style="margin-bottom:8px;">
          <h3 style="margin:0; font-size: 14px;">Pinned</h3>
          <span>${escapeHtml(pinnedIcon)}</span>
        </div>
        <a href="${escapeHtml(pinnedUrl)}" target="_blank" style="color:var(--primary); text-decoration:none; font-weight:800; font-size:13px;">${escapeHtml(pinnedTitle)}</a>
      </div>
    `;
  }

  const music = getVal("music");
  if (music) {
    setSrc("previewMusic", music);
    setDisplay("previewMusicWrap", "block");
  } else {
    setDisplay("previewMusicWrap", "none");
  }

  const yt = getVal("youtubeEmbed");
  if (yt) {
    setSrc("previewVideo", yt);
    setDisplay("previewVideoWrap", "block");
  } else {
    setDisplay("previewVideoWrap", "none");
  }

  const customCss = getVal("customCss");
  if (customCss) {
    let styleEl = document.getElementById("bio-custom-css-preview");
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "bio-custom-css-preview";
      document.head.appendChild(styleEl);
    }
    styleEl.textContent = customCss;
  }

  const previewLinks = $("previewLinks");
  if (previewLinks) {
    let linksHtml = pinnedHtml;
    document.querySelectorAll(".linkItem").forEach((item) => {
      const title = item.querySelector(".linkTitle")?.value || "";
      const url = item.querySelector(".linkUrl")?.value || "";
      const icon = item.querySelector(".linkIcon")?.value || "🔗";
      if (title && url) {
        linksHtml += `
          <a class="previewLink" href="${escapeHtml(url)}" target="_blank" style="display: flex; align-items: center; gap: 12px; justify-content: space-between; text-decoration: none; background: var(--primary); color: #000; padding: 14px; border-radius: 5px; font-weight: 700; font-size: 13px;">
            <span class="previewLinkLeft" style="display: flex; align-items: center; gap: 12px;">
              <span class="previewLinkIcon" style="width: 36px; height: 36px; border-radius: 5px; display: flex; align-items: center; justify-content: center; color: #000; font-weight: 800; background: rgba(255,255,255,.5);">${escapeHtml(icon)}</span>
              <span class="previewLinkText">
                <div>${escapeHtml(title)}</div>
              </span>
            </span>
            <span>→</span>
          </a>
        `;
      }
    });
    previewLinks.innerHTML = linksHtml;
  }

  const previewSocials = $("previewSocials");
  if (previewSocials) {
    previewSocials.innerHTML = "";
    ["instagram", "youtube", "tiktok", "github", "telegram", "discord"].forEach((key) => {
      const url = getVal(key);
      if (url) {
        previewSocials.innerHTML += `<a href="${escapeHtml(url)}" target="_blank" style="background: #141414; border: 1px solid var(--border); color: #fff; text-decoration: none; padding: 8px 12px; border-radius: 5px; font-size: 13px; font-weight: 600; margin-right: 8px;">${socialIcon(key)} ${socialLabel(key)}</a>`;
      }
    });
  }

  const previewProducts = $("previewProducts");
  let hasProducts = false;
  if (previewProducts) {
    previewProducts.innerHTML = "";
    document.querySelectorAll(".productItem").forEach((item) => {
      const title = item.querySelector(".productTitle")?.value || "";
      const price = item.querySelector(".productPrice")?.value || "";
      const image = item.querySelector(".productImage")?.value || "";
      const url = item.querySelector(".productUrl")?.value || "";
      if (title) {
        hasProducts = true;
        previewProducts.innerHTML += `
          <div class="product" style="background:#111; border:1px solid #222; border-radius:12px; overflow:hidden; padding-bottom:14px; text-align: left;">
            <img src="${escapeHtml(image)}" style="width: 100%; aspect-ratio: 1/1; object-fit: cover;">
            <h4 style="padding: 14px 14px 6px; font-size: 14px;">${escapeHtml(title)}</h4>
            <p style="padding: 0 14px 12px; color: #888; font-size: 12px;">${escapeHtml(price)}</p>
            <a class="buyBtn" href="${escapeHtml(url)}" target="_blank" style="display: block; margin: 0 14px; text-align: center; background: var(--primary); color: #000; text-decoration: none; padding: 10px; border-radius: 5px; font-weight: 800; font-size: 13px;">Open</a>
          </div>
        `;
      }
    });
  }
  setDisplay("previewShopWrap", hasProducts ? "block" : "none");

  const previewGallery = $("previewGallery");
  let hasGallery = false;
  if (previewGallery) {
    previewGallery.innerHTML = "";
    document.querySelectorAll(".galleryInput").forEach((item) => {
      const src = item.value.trim();
      if (src) {
        hasGallery = true;
        previewGallery.innerHTML += `<img src="${escapeHtml(src)}" style="width: 100%; border-radius: 10px; aspect-ratio: 1/1; object-fit: cover;">`;
      }
    });
  }
  setDisplay("previewGalleryWrap", hasGallery ? "block" : "none");

  const emailLabel = getVal("emailLabel");
  if (emailLabel) {
    setText("previewEmailLabel", emailLabel);
    setDisplay("previewSubscribeWrap", "block");
  } else {
    setDisplay("previewSubscribeWrap", "none");
  }

  updateBioUrl();
  renderStats();
}

function renderStats() {
  setText("statViews", currentBio?.views || 0);
  setText("statClicks", currentBio?.clicks || 0);
  setText("statLinks", document.querySelectorAll(".linkItem").length);
  setText("statGallery", document.querySelectorAll(".galleryItem").length);
}

window.addLink = function (item = {}) {
  const div = document.createElement("div");
  div.className = "linkItem";
  // Escape data dinamis dalam atribut HTML
  div.innerHTML = `
    <input class="input linkTitle" placeholder="Title" value="${escapeHtml(item.title || "")}">
    <input class="input linkUrl" placeholder="https://..." value="${escapeHtml(item.url || "")}">
    <input class="input linkIcon" placeholder="🔗" value="${escapeHtml(item.icon || "🔗")}">
    <button class="btnDark" onclick="this.parentElement.remove(); renderPreview();">Remove</button>
  `;

  if ($("linksBox")) $("linksBox").appendChild(div);

  div.querySelectorAll("input").forEach((input) => {
    input.addEventListener("input", renderPreview);
  });
  renderPreview();
};

window.addGalleryItem = function (src = "") {
  const div = document.createElement("div");
  div.className = "galleryItem";
  div.innerHTML = `
    <input class="input galleryInput" placeholder="Image URL" value="${escapeHtml(src)}">
    <button class="btnDark" onclick="this.parentElement.remove(); renderPreview(); renderStats();">Remove</button>
  `;

  if ($("galleryBox")) $("galleryBox").appendChild(div);

  div.querySelector("input").addEventListener("input", renderPreview);
  renderPreview();
  renderStats();
};

window.addProductItem = function (item = {}) {
  const div = document.createElement("div");
  div.className = "productItem";
  div.innerHTML = `
    <input class="input productTitle" placeholder="Product title" value="${escapeHtml(item.title || "")}">
    <input class="input productPrice" placeholder="Price" value="${escapeHtml(item.price || "")}">
    <input class="input productImage" placeholder="Image URL" value="${escapeHtml(item.image || "")}">
    <input class="input productUrl" placeholder="Product URL" value="${escapeHtml(item.url || "")}">
    <button class="btnDark" onclick="this.parentElement.remove(); renderPreview(); renderStats();">Remove</button>
  `;

  if ($("productsBox")) $("productsBox").appendChild(div);

  div.querySelectorAll("input").forEach((input) => {
    input.addEventListener("input", renderPreview);
  });

  renderPreview();
  renderStats();
};

function socialLabel(key) {
  const labels = { instagram: "Instagram", youtube: "YouTube", tiktok: "TikTok", github: "GitHub", telegram: "Telegram", discord: "Discord" };
  return labels[key] || key;
}

function socialIcon(key) {
  const icons = { instagram: "📸", youtube: "▶", tiktok: "🎵", github: "⌂", telegram: "✈", discord: "💬" };
  return icons[key] || "•";
}

[
  "username", "displayName", "bio",
  "instagram", "youtube", "tiktok", "github", "telegram", "discord",
  "music", "youtubeEmbed", "donate",
  "coverVideo", "shareText", "customCss",
  "emailLabel", "ogTitle", "ogDesc",
  "pinnedTitle", "pinnedUrl", "pinnedIcon", "bioPassword",
  "activeFrom", "activeUntil", "primaryColor"
].forEach((id) => {
  const el = $(id);
  if (el) el.addEventListener("input", renderPreview);
});

["verified", "hideBranding", "passwordMode", "scheduleMode", "allowComments"].forEach((id) => {
  const el = $(id);
  if (el) el.addEventListener("change", renderPreview);
});

if ($("theme")) $("theme").addEventListener("change", renderPreview);

document.querySelectorAll(".themeSwatch").forEach((swatch) => {
  swatch.addEventListener("click", () => {
    const classes = Array.from(swatch.classList);
    const selectedTheme = classes.find(c => c !== "themeSwatch");
    if (selectedTheme && $("theme")) {
      $("theme").value = selectedTheme;
      $("theme").dispatchEvent(new Event("change"));
    }
  });
});

if ($("avatarUpload")) {
  $("avatarUpload").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      toast("Uploading avatar...");
      avatarUrl = await uploadImage(file);
      setSrc("previewAvatar", avatarUrl);
      setSrc("avatarPreviewMini", avatarUrl);
      toast("Avatar uploaded");
      renderPreview();
    } catch (err) {
      toast("Upload failed", "error");
    }
  });
}

if ($("coverUpload")) {
  $("coverUpload").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      toast("Uploading cover...");
      coverUrl = await uploadImage(file);
      if ($("previewCover")) $("previewCover").style.backgroundImage = `url('${coverUrl}')`;
      setSrc("coverPreviewMini", coverUrl);
      toast("Cover uploaded");
      renderPreview();
    } catch (err) {
      toast("Upload failed", "error");
    }
  });
}

window.saveBio = async function () {
  try {
    if (!currentUser) {
      toast("Login required", "error");
      return;
    }

    const username = getVal("username").trim().toLowerCase().replace(/[^a-z0-9_\-]/g, "");
    if (!username) {
      toast("Username required", "error");
      return;
    }

    const links = [];
    document.querySelectorAll(".linkItem").forEach((item) => {
      const title = item.querySelector(".linkTitle")?.value || "";
      const url = item.querySelector(".linkUrl")?.value || "";
      const icon = item.querySelector(".linkIcon")?.value || "🔗";
      if (title && url) links.push({ title, url, icon });
    });

    const gallery = [];
    document.querySelectorAll(".galleryInput").forEach((item) => {
      if (item.value.trim()) gallery.push(item.value.trim());
    });

    const products = [];
    document.querySelectorAll(".productItem").forEach((item) => {
      const title = item.querySelector(".productTitle")?.value || "";
      const price = item.querySelector(".productPrice")?.value || "";
      const image = item.querySelector(".productImage")?.value || "";
      const url = item.querySelector(".productUrl")?.value || "";
      if (title) products.push({ title, price, image, url });
    });

    const data = {
      uid: currentUser.uid,
      username,
      name: getVal("displayName"),
      bio: getVal("bio"),
      avatar: avatarUrl,
      cover: coverUrl,
      theme: getVal("theme"),
      primaryColor: getVal("primaryColor"),
      verified: getChecked("verified"),
      hideBranding: getChecked("hideBranding"),
      music: getVal("music"),
      youtubeEmbed: getVal("youtubeEmbed"),
      donate: getVal("donate"),
      
      coverVideo: getVal("coverVideo"),
      shareText: getVal("shareText"),
      customCss: getVal("customCss"),
      emailLabel: getVal("emailLabel"),
      ogTitle: getVal("ogTitle"),
      ogDesc: getVal("ogDesc"),
      pinnedTitle: getVal("pinnedTitle"),
      pinnedUrl: getVal("pinnedUrl"),
      pinnedIcon: getVal("pinnedIcon"),
      passwordMode: getChecked("passwordMode"),
      scheduleMode: getChecked("scheduleMode"),
      allowComments: getChecked("allowComments"),
      bioPassword: getVal("bioPassword"),
      activeFrom: getVal("activeFrom"),
      activeUntil: getVal("activeUntil"),

      socials: {
        instagram: getVal("instagram"),
        youtube: getVal("youtube"),
        tiktok: getVal("tiktok"),
        github: getVal("github"),
        telegram: getVal("telegram"),
        discord: getVal("discord")
      },

      links,
      gallery,
      products,

      views: currentBio?.views || 0,
      clicks: currentBio?.clicks || 0,
      created: currentBio?.created || Date.now(),
      updatedAt: Date.now()
    };

    // Menggunakan currentUser yang sudah divalidasi
    const token = await currentUser.getIdToken();
    const res = await fetch("https://dyshort-worker.myling.workers.dev/api/save-bio", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify(data)
    });

    const result = await res.json();
    
    if (!result.success) throw new Error(result.message);

    localStorage.setItem("dy_bio_username", username);
    
    const snap = await get(ref(db, "bios/" + username));
    currentBio = snap.exists() ? snap.val() : data;

    updateBioUrl();
    renderPreview();
    renderStats();
    await loadBioList();

    if (result.sanitized) {
      toast("Tersimpan! Fitur premium dimatikan (Paket Free)", "success");
    } else {
      toast("Bio saved successfully");
    }
  } catch (err) {
    console.error(err);
    alert("DETAIL ERROR: " + err.code + " - " + err.message);
    toast("Save failed", "error");
  }
};

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    toast("Login Required", "error");
    setTimeout(() => {
      window.location.href = "/login.html";
    }, 800);
    return;
  }

  currentUser = user;
  await loadBioList();

  const lastUsername = localStorage.getItem("dy_bio_username");
  if (lastUsername) {
    await editBio(lastUsername);
  } else {
    renderPreview();
    renderStats();
  }
});