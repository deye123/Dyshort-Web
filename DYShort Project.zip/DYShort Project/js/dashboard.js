import app from "/js/firebase-init.js";

import {
  getDatabase,
  ref,
  onValue,
  get,
  push,
  set
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

import {
  getAuth,
  onAuthStateChanged,
  signOut,
  updatePassword,
  updateProfile
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import {
  getMessaging,
  getToken
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging.js";

const appInstance = app;
const db = getDatabase(appInstance);
const auth = getAuth(appInstance);

let messaging = null;
try {
  messaging = getMessaging(appInstance);
} catch (err) {
  console.warn("Messaging disabled:", err);
}

/* =========================
   GLOBAL STATE
========================= */
let currentUser = null;
let rawLinks = [];
let allLinks = [];
let filteredLinks = [];
let currentPage = 1;
const perPage = 10;
let isPremium = false;
let isAdmin = false;
let domainsUnsubscribe = null;

/* =========================
   HELPERS
========================= */
function $(id) {
  return document.getElementById(id);
}

function escapeHtml(str = "") {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function randomString(length = 5) {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

function showToast(text, type = "success") {
  const toast = $("toast");
  const toastText = $("toastText");
  if (!toast || !toastText) return;

  toast.className = type;
  toast.style.display = "block";
  toastText.textContent = text;

  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => {
    toast.style.display = "none";
  }, 2500);
}
window.showToast = showToast;

function getSlugFromPath() {
  let path = window.location.pathname.replace(/^\/+|\/+$/g, "");
  let parts = path.split("/");
  let slug = parts[parts.length - 1] || "";
  if (slug.toLowerCase().endsWith(".html")) slug = slug.slice(0, -5);
  return slug;
}

/* =========================
   SIDEBAR & MODALS
========================= */
window.toggleSidebar = function () {
  $("sidebar")?.classList.toggle("show");
  $("overlay")?.classList.toggle("show");
};

window.openCreate = function () {
  $("createBox")?.scrollIntoView({ behavior: "smooth" });
  $("templateSelect")?.focus();
};

window.openSettings = function () {
  $("settingsModal").style.display = "flex";
};
window.closeSettings = function () {
  $("settingsModal").style.display = "none";
};
window.openLPModal = function () {
  $("lpModal").style.display = "flex";
};
window.closeLPModal = function () {
  $("lpModal").style.display = "none";
};
window.openDomainModal = function () {
  $("domainModal").style.display = "flex";
};
window.closeDomainModal = function () {
  $("domainModal").style.display = "none";
};
window.closeCongratsModal = function () {
  $("congratsModal").style.display = "none";
};
window.closeFreeWarningModal = function () {
  $("freeWarningModal").style.display = "none";
};

/* =========================
   LOGOUT & COPY
========================= */
window.logoutUser = async function () {
  try {
    await signOut(auth);
    location.href = "/";
  } catch (err) {
    console.error(err);
    showToast("Logout gagal", "error");
  }
};

window.copyLink = async function (text) {
  try {
    await navigator.clipboard.writeText(text);
    showToast("Copied!");
  } catch (err) {
    showToast("Copy failed", "error");
  }
};

/* =========================
   DELETE LINK
========================= */
window.deleteLink = async function (slug) {
  if (!confirm("Delete this link?")) return;

  try {
    const token = await auth.currentUser.getIdToken(true);
    const res = await fetch("https://api.dyshort.pro/api/delete", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify({ slug })
    });

    const result = await res.json();
    if (!result.success) throw new Error(result.message || "Gagal menghapus link");

    rawLinks = rawLinks.filter((l) => l.slug !== slug && l.publicSlug !== slug);
    allLinks = allLinks.filter((l) => l.slug !== slug && l.publicSlug !== slug);
    filteredLinks = [...allLinks];

    const maxPage = Math.max(1, Math.ceil(filteredLinks.length / perPage));
    if (currentPage > maxPage) currentPage = maxPage;

    if ($("totalLinks")) $("totalLinks").textContent = allLinks.length;
    renderCurrentPage();
    showToast("Deleted");
  } catch (err) {
    console.error(err);
    showToast(err.message, "error");
  }
};

/* =========================
   PAGINATION & RENDER
========================= */
function renderPagination() {
  const pagination = $("pagination");
  if (!pagination) return;

  pagination.innerHTML = "";

  const totalPages = Math.ceil(filteredLinks.length / perPage);
  if ($("pageInfo")) $("pageInfo").innerHTML = totalPages <= 1 ? "" : `Page ${currentPage} of ${totalPages}`;

  if (totalPages <= 1) return;

  if (currentPage > 1) {
    const prev = document.createElement("button");
    prev.innerHTML = "‹";
    prev.onclick = () => {
      currentPage--;
      renderCurrentPage();
    };
    pagination.appendChild(prev);
  }

  let startPage = Math.max(1, currentPage - 2);
  let endPage = Math.min(totalPages, startPage + 4);
  if (endPage - startPage < 4) startPage = Math.max(1, endPage - 4);

  for (let i = startPage; i <= endPage; i++) {
    const btn = document.createElement("button");
    btn.textContent = i;
    if (i === currentPage) btn.classList.add("active");
    btn.onclick = () => {
      currentPage = i;
      renderCurrentPage();
    };
    pagination.appendChild(btn);
  }

  if (currentPage < totalPages) {
    const next = document.createElement("button");
    next.innerHTML = "›";
    next.onclick = () => {
      currentPage++;
      renderCurrentPage();
    };
    pagination.appendChild(next);
  }
}

function renderLinks(list) {
  const container = $("linksContainer");
  if (!container) return;

  if (list.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <h3>No links found</h3>
        <p style="font-size:14px;">Create your first shortlink</p>
      </div>
    `;
    return;
  }

  container.innerHTML = "";

  list.forEach((item) => {
    const date = new Date(item.created || Date.now()).toLocaleString();
    const shortlink = item.shortlink || "";
    const qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" + encodeURIComponent(shortlink);
    const adDisplay = (item.ad_clicks !== null && item.ad_clicks !== undefined) ? item.ad_clicks : "-";

    container.innerHTML += `
      <div class="link-row">
        <div class="col-data" data-label="Slug">${escapeHtml(item.publicSlug || item.slug || "-")}</div>
        <div class="col-data" data-label="Shortlink">
          <a class="shortlink" target="_blank" href="${escapeHtml(shortlink)}">${escapeHtml(shortlink)}</a>
        </div>
        <div class="col-data" data-label="Dest. URL" title="${escapeHtml(item.url || "-")}">${escapeHtml(item.url || "-")}</div>
        <div class="col-data" data-label="Clicks">${Number(item.clicks || 0)}</div>
        <div class="col-data" data-label="Ad Clicks">${adDisplay}</div>
        <div class="col-data" data-label="Created">${escapeHtml(date)}</div>
        <div class="col-data action-buttons">
          <button class="btnSmall copyBtn" onclick='copyLink(${JSON.stringify(shortlink)})'>Copy</button>
          <button class="btnSmall qrBtn" onclick='window.open(${JSON.stringify(qrUrl)}, "_blank")'>QR</button>
          <button class="btnSmall delBtn" onclick='deleteLink(${JSON.stringify(item.slug || item.publicSlug || "")})'>Del</button>
        </div>
      </div>
    `;
  });
}

function renderCurrentPage() {
  const start = (currentPage - 1) * perPage;
  const end = start + perPage;
  renderLinks(filteredLinks.slice(start, end));
  renderPagination();
}

async function loadLinks(uid) {
  try {
    if (!uid) {
      showToast("UID tidak ditemukan", "error");
      return;
    }

    if (!auth.currentUser) {
      showToast("User tidak terautentikasi", "error");
      setTimeout(() => location.href = "/", 1500);
      return;
    }

    const token = await auth.currentUser.getIdToken(true);
    const apiUrl =
`https://api.dyshort.pro/api/links?_=${Date.now()}`;

    const res = await fetch(apiUrl, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache"
      }
    });

    if (!res.ok) {
      const errorText = await res.text();
      throw new Error(`Server error: ${res.status} ${errorText.slice(0, 120)}`);
    }

const contentType = res.headers.get("content-type");
if (!contentType || !contentType.includes("application/json")) {
  const rawText = await res.text(); 
  throw new Error(`Bukan JSON. Isi Server: "${rawText.slice(0, 100)}"`);
}

    const result = await res.json();
    if (!result.success) {
      throw new Error(result.message || "API error");
    }

    rawLinks = Array.isArray(result.links) ? result.links : [];
        allLinks = rawLinks.map((link) => ({
      ...link,
      clicks: Number(link.clicks || 0),
      ad_clicks: link.ad_clicks === "-" ? "-" : (link.ad_clicks === null || link.ad_clicks === undefined ? null : Number(link.ad_clicks || 0)),
      today_clicks: Number(link.today_clicks || 0),
      created: Number(link.created || 0)
    }));

    allLinks.sort((a, b) => b.created - a.created);
    filteredLinks = [...allLinks];
    currentPage = 1;

    let totalClicks = 0;
    let todayClicks = 0;
    for (const link of allLinks) {
      totalClicks += Number(link.clicks || 0);
      todayClicks += Number(link.today_clicks || 0);
    }

    if ($("totalLinks")) $("totalLinks").textContent = allLinks.length;
    if ($("totalClicks")) $("totalClicks").textContent = totalClicks;
    if ($("todayClicks")) $("todayClicks").textContent = todayClicks;

    renderCurrentPage();
  } 
  catch (err) {
    console.error("LOAD LINKS ERROR:", err);
    
    // 1. Paksa HP memunculkan popup alert berisi teks eror asli
    alert("KOTAK EROR ASLI:\n" + err.message);
    
    // 2. Hancurkan desain HTML dashboard dan ganti dengan teks mentah
    const container = $("linksContainer");
    if (container) {
      container.innerHTML = `
        <div style="background:#1e1e1e; color:#ff5252; padding:20px; font-family:monospace; font-size:13px; white-space:pre-wrap; word-break:break-all; border:3px solid #ff0000; border-radius:8px; margin:20px 0; text-align:left;">
          <h3 style="color:#fff; margin-top:0; border-bottom:1px solid #ff5252; padding-bottom:10px;">🚨 RAW ERROR LOG (MODE HP)</h3>
          <p><strong>Pesan Eror:</strong></p>
          <div style="background:#000; color:#00ff00; padding:10px; border-radius:4px; overflow-x:auto;">
            ${err.message}
          </div>
        </div>
      `;
    }
    
    if (typeof showToast === "function") {
      showToast("Eror terdeteksi, cek layar!", "error");
    }
  }
}
/* =========================
   SEARCH & TEMPLATE FIELDS
========================= */
let searchTimeout;
$("searchInput")?.addEventListener("input", (e) => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {
    const q = e.target.value.toLowerCase();
    filteredLinks = allLinks.filter(
      (l) =>
        (l.slug || "").toLowerCase().includes(q) ||
        (l.publicSlug || "").toLowerCase().includes(q) ||
        (l.shortlink || "").toLowerCase().includes(q) ||
        (l.url || "").toLowerCase().includes(q)
    );
    currentPage = 1;
    renderCurrentPage();
  }, 150);
});

window.toggleTemplateFields = function () {
  const template = $("templateSelect")?.value || "";
  const premiumTemplates = ["v1dzy", "template_v2", "slicedrive", "template_v5"];

  if (premiumTemplates.includes(template) && !isPremium && !isAdmin) {
    showToast("Template ini khusus untuk pengguna Premium!", "error");
    return;
  }

  if ($("directFields")) $("directFields").style.display = "none";
  if ($("v1dzyFields")) $("v1dzyFields").style.display = "none";
  if ($("v2Fields")) $("v2Fields").style.display = "none";
  if ($("slicedriveFields")) $("slicedriveFields").style.display = "none";
  if ($("v4Fields")) $("v4Fields").style.display = "none";
  if ($("v5Fields")) $("v5Fields").style.display = "none";

  if (template === "") {
    if ($("directFields")) $("directFields").style.display = "block";
  } else if (template === "v1dzy") {
    if ($("v1dzyFields")) $("v1dzyFields").style.display = "block";
  } else if (template === "template_v2") {
    if ($("v2Fields")) $("v2Fields").style.display = "block";
  } else if (template === "slicedrive") {
    if ($("slicedriveFields")) $("slicedriveFields").style.display = "block";
  } else if (template === "template_v4") {
    if ($("v4Fields")) $("v4Fields").style.display = "block";
  } else if (template === "template_v5") {
    if ($("v5Fields")) $("v5Fields").style.display = "block";
  }
};

/* =========================
   CREATE LINK
========================= */
window.createLink = async function () {
  try {
    if (!currentUser) {
      showToast("Login required", "error");
      return;
    }

    const userRef = ref(db, "users/" + currentUser.uid);
    const snapshot = await get(userRef);

    let userPlan = "free";
    let userRole = "";
    let isExpired = false;
    let dailyCount = 0;
    let lastDate = "";

    if (snapshot.exists()) {
      const userData = snapshot.val();
      userPlan = userData.plan || "free";
      userRole = userData.role || "";
      isExpired = userData.expiredAt && Date.now() > userData.expiredAt;
      dailyCount = Number(userData.daily_link_count || 0);
      lastDate = userData.last_link_date || "";
    }

    const premiumActive = Boolean((userPlan && (userPlan.includes("premium") || userPlan.includes("admin"))) && !isExpired);
    const adminActive = userRole === "admin";

    const maxFreeDaily = 10;
    const todayStr = new Date().toISOString().split("T")[0];
    if (!adminActive && !premiumActive && lastDate === todayStr && dailyCount >= maxFreeDaily) {
      showToast(`Limit harian gratis (${maxFreeDaily} link) habis! Upgrade ke Premium.`, "error");
      setTimeout(() => { location.href = "/pricing.html"; }, 1500);
      return;
    }

    const template = $("templateSelect")?.value || "";
    let selectedDomain = window.APP_CONFIG?.domain?.main || location.origin;
    const domainSelect = $("domainSelect");
    if (domainSelect && domainSelect.value) selectedDomain = domainSelect.value;

    let targetUrl = "";
    let videoUrl = "";
    let buttonUrl = "";
    let redirectUrl = "";
    let videoUrls = [];
    let secondUrl = "";

    if (template === "v1dzy") {
      videoUrl = $("videoUrlInput")?.value.trim() || "";
      buttonUrl = $("buttonUrlInput")?.value.trim() || "";
      if (!videoUrl || !buttonUrl) return showToast("Lengkapi video URL dan button URL", "error");
      targetUrl = buttonUrl;
    } else if (template === "template_v2") {
      videoUrl = $("videoUrlInputV2")?.value.trim() || "";
      buttonUrl = $("buttonUrlInputV2")?.value.trim() || "";
      redirectUrl = $("redirectUrlInputV2")?.value.trim() || "";
      if (!videoUrl || !buttonUrl || !redirectUrl) return showToast("Lengkapi semua field untuk Template V2", "error");
      targetUrl = redirectUrl;
    } else if (template === "slicedrive") {
      videoUrls = ($("videoUrlsInput")?.value || "").split("\n").map((s) => s.trim()).filter(Boolean);
      const buttonUrlSlice = $("buttonUrlInputSlice")?.value.trim() || "";
      const autoRedirectUrlSlice = $("autoRedirectUrlInputSlice")?.value.trim() || "";
      if (!videoUrls.length || (!buttonUrlSlice && !autoRedirectUrlSlice)) {
        return showToast("Lengkapi field video dan minimal satu URL tujuan", "error");
      }
      targetUrl = buttonUrlSlice || autoRedirectUrlSlice;
    } else if (template === "template_v4") {
      redirectUrl = $("mainUrlInputV4Dash")?.value.trim() || "";
      secondUrl = $("secondUrlInputV4Dash")?.value.trim() || "";
      if (!redirectUrl || !secondUrl) return showToast("Lengkapi semua field untuk Template V4", "error");
      targetUrl = redirectUrl;
    } else if (template === "template_v5") {
      const btn1 = $("btn1")?.value.trim() || "";
      const btn2 = $("btn2")?.value.trim() || "";
      const btn3 = $("btn3")?.value.trim() || "";
      if (!btn1 || !btn2 || !btn3) return showToast("Lengkapi semua field tombol untuk Template V5", "error");
      targetUrl = btn1;
    } else {
      targetUrl = $("directUrlInput")?.value.trim() || "";
      if (!targetUrl) return showToast("Masukkan URL Tujuan", "error");
    }

    try {
      new URL(targetUrl);
    } catch {
      return showToast("Invalid URL", "error");
    }

    const customAlias = $("customAliasInput")?.value.trim().replace(/\s+/g, "-").replace(/[^a-zA-Z0-9-_]/g, "") || "";
    const publicSlug = customAlias !== ""
      ? (customAlias.endsWith(".mp4") ? customAlias : customAlias + ".mp4")
      : randomString(5) + ".mp4";
    const slug = publicSlug.replace(/\./g, "_");
    const cleanDomain = String(selectedDomain).replace(/\/+$/, "");
    const shortlink = cleanDomain + "/" + publicSlug;

    const expireVal = $("expireInput")?.value || "";
    const expiredAt = expireVal ? new Date(expireVal).getTime() : null;

    const saveData = {
      uid: currentUser.uid,
      email: currentUser.email || "",
      slug,
      publicSlug,
      shortlink,
      url: targetUrl,
      customAlias,
      domain: String(selectedDomain).replace("https://", "").replace("http://", "").replace("/", ""),
      clicks: 0,
      created: Date.now(),
      expiredAt,
      ogTitle: $("ogTitleInput")?.value.trim() || "",
      ogDesc: $("ogDescInput")?.value.trim() || "",
      ogImage: $("ogImageInput")?.value.trim() || ""
    };

    if (template === "v1dzy") {
      saveData.template = "v1dzy";
      saveData.fields = { videoUrl, buttonUrl };
    } else if (template === "template_v2") {
      saveData.template = "template_v2";
      saveData.fields = { videoUrl, buttonUrl, redirectUrl };
    } else if (template === "slicedrive") {
      saveData.template = "slicedrive";
      saveData.fields = {
        videoUrls,
        buttonUrl: $("buttonUrlInputSlice")?.value.trim() || "",
        autoRedirectUrl: $("autoRedirectUrlInputSlice")?.value.trim() || ""
      };
    } else if (template === "template_v4") {
      saveData.template = "template_v4";
      saveData.fields = { redirectUrl, secondUrl };
    } else if (template === "template_v5") {
      saveData.template = "template_v5";
      saveData.fields = {
        btn1: $("btn1")?.value.trim() || "",
        btn2: $("btn2")?.value.trim() || "",
        btn3: $("btn3")?.value.trim() || ""
      };
    } else {
      saveData.template = "";
      saveData.fields = {};
    }

    const token = await auth.currentUser.getIdToken(true);
    const res = await fetch("https://api.dyshort.pro/api/create", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify(saveData)
    });

    const result = await res.json();
    if (!result.success) {
      if (result.message && result.message.includes("Premium")) {
        showToast(result.message, "error");
        setTimeout(() => { location.href = "/pricing.html"; }, 1500);
      } else {
        showToast(result.message || "Gagal membuat link", "error");
      }
      return;
    }
    
    if (!adminActive && !premiumActive) {
      const newCount = lastDate === todayStr ? dailyCount + 1 : 1;
      await set(ref(db, "users/" + currentUser.uid + "/daily_link_count"), newCount);
      await set(ref(db, "users/" + currentUser.uid + "/last_link_date"), todayStr);
    }

    const mergedItem = {
      ...saveData,
      ...(result.link || {}),
      clicks: Number((result.link && result.link.clicks) || saveData.clicks || 0),
      created: Number((result.link && result.link.created) || saveData.created || Date.now())
    };

    document.querySelectorAll("#createBox input").forEach((inp) => (inp.value = ""));
    document.querySelectorAll("#createBox textarea").forEach((inp) => (inp.value = ""));
    if ($("templateSelect")) $("templateSelect").value = "";
    toggleTemplateFields();

    showToast("Link berhasil dibuat!");

    rawLinks.unshift(mergedItem);
    allLinks.unshift(mergedItem);
    filteredLinks = [...allLinks];

    if ($("totalLinks")) $("totalLinks").textContent = allLinks.length;
    currentPage = 1;
    renderCurrentPage();
  } catch (err) {
    console.error(err);
    showToast(err.message, "error");
  }
};

/* =========================
   SETTINGS, LP, DOMAIN, NOTIF
========================= */
window.saveSettings = async function () {
  try {
    const username = $("newUsername")?.value.trim() || "";
    const password = $("newPassword")?.value.trim() || "";

    if (username) {
      await updateProfile(auth.currentUser, { displayName: username });
      if ($("userName")) $("userName").textContent = username;
    }
    if (password) await updatePassword(auth.currentUser, password);

    showToast("Account updated");
    closeSettings();
  } catch (err) {
    showToast(err.message, "error");
  }
};

window.saveLP = async function () {
  try {
    await set(push(ref(db, "landingpages")), {
      title: $("lpTitle")?.value || "",
      description: $("lpDesc")?.value || "",
      image: $("lpImage")?.value || "",
      preview: $("lpPreview")?.value || "",
      price: $("lpPrice")?.value || "",
      category: $("lpCategory")?.value || "",
      active: true
    });
    showToast("Landing page added");
    closeLPModal();
  } catch (err) {
    showToast(err.message, "error");
  }
};

window.saveDomain = async function () {
  try {
    const domain = $("domainInput")?.value.trim() || "";
    if (!domain) return showToast("Enter domain", "error");

    await set(push(ref(db, "domains")), {
      name: $("domainName")?.value.trim() || "",
      url: domain,
      premium: $("premiumCheck")?.checked || false,
      active: true
    });
    showToast("Domain added");
    closeDomainModal();
  } catch (err) {
    showToast(err.message, "error");
  }
};

function loadDomains(userPlan, isExpired, userRole) {
  const select = $("domainSelect");
  if (!select) return;

  const isPremiumUser = userPlan && (userPlan.includes("premium") || userPlan.includes("admin")) && !isExpired;
  const isAdminUser = userRole === "admin";

  if (domainsUnsubscribe) {
    domainsUnsubscribe();
    domainsUnsubscribe = null;
  }

  domainsUnsubscribe = onValue(ref(db, "domains"), (snapshot) => {
    select.innerHTML = "";
    if (snapshot.exists()) {
      const data = snapshot.val();
      Object.keys(data).forEach((key) => {
        const item = data[key];
        if (item.active === false) return;

        if (item.ownerUid && currentUser && item.ownerUid !== currentUser.uid && !isAdminUser) {
          return;
        }

        const option = document.createElement("option");
        option.value = item.url || item.domain || "";
        const nameText = item.name || item.url || item.domain || "Domain";

        if (item.premium === true) {
          if (!isPremiumUser) {
            option.textContent = `🔒 ${nameText} (Premium Only)`;
            option.disabled = true;
            option.style.color = "#555";
          } else {
            option.textContent = `⭐ ${nameText} (Premium)`;
          }
        } else {
          option.textContent = nameText;
        }

        select.appendChild(option);
      });
    } else {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "No domains";
      select.appendChild(option);
    }
  });
}

$("notifBtn")?.addEventListener("click", async () => {
  if (!messaging) return showToast("Notifikasi tidak tersedia", "error");

  try {
    const permission = await Notification.requestPermission();
    if (permission !== "granted") return alert("Izin notifikasi ditolak");

    const registration = await navigator.serviceWorker.register("/firebase-messaging-sw.js");
    await navigator.serviceWorker.ready;

    await getToken(messaging, {
      vapidKey: "BJcGTtaxWsDZPcpuXCb9alViCD9CGd7v_Eyg0pu4hCOFZo6hC1xwLGzJebk20SDNPQZcHEp1t-JRNW98xsHTF5I",
      serviceWorkerRegistration: registration
    });

    alert("Notifikasi aktif");
    $("notifBtn").style.display = "none";
  } catch (error) {
    alert("Error: " + error.message);
  }
});

/* =========================
   AUTH REALTIME
========================= */
onAuthStateChanged(auth, async (user) => {
  if (user) {
    currentUser = user;
    if ($("userEmail")) $("userEmail").textContent = user.email || "";
    if ($("userName")) $("userName").textContent = user.displayName || "User";

    setTimeout(() => {
      loadLinks(user.uid);
    }, 1000);

    const userRef = ref(db, "users/" + user.uid);
    onValue(userRef, (snapshot) => {
      let userPlan = "free";
      let userRole = "";
      let isExpired = false;
      let expiredAt = null;

      if (snapshot.exists()) {
        const userData = snapshot.val();
        userPlan = userData.plan || "free";
        userRole = userData.role || "";
        expiredAt = userData.expiredAt || null;
        isExpired = expiredAt && Date.now() > expiredAt;
      }

      let displayPlanText = "👤 Free Plan";
      let displayPlanColor = "var(--text-muted)";
      let isPremiumActive = false;

      if (userRole === "admin" || userPlan === "admin") {
        displayPlanText = "⚙️ Admin";
        displayPlanColor = "var(--primary)";
        isPremiumActive = true;
        isAdmin = true;
        isPremium = true;
      } else if (userPlan === "premium" && !isExpired) {
        displayPlanText = "💎 Premium Plan";
        displayPlanColor = "var(--primary)";
        isPremiumActive = true;
        isAdmin = false;
        isPremium = true;
      } else {
        displayPlanText = "👤 Free Plan";
        displayPlanColor = "var(--text-muted)";
        isPremiumActive = false;
        isAdmin = false;
        isPremium = false;
      }

      const userPlanEl = $("userPlan");
      if (userPlanEl) {
        userPlanEl.textContent = displayPlanText;
        userPlanEl.style.color = displayPlanColor;
      }

      const userPlanExpiryEl = $("userPlanExpiry");
      if (userPlanExpiryEl) {
        if (isPremiumActive && expiredAt && userRole !== "admin") {
          const expDate = new Date(expiredAt).toLocaleDateString("id-ID", {
            day: "numeric",
            month: "long",
            year: "numeric"
          });
          userPlanExpiryEl.textContent = `Aktif s/d: ${expDate}`;
          userPlanExpiryEl.style.display = "block";
        } else {
          userPlanExpiryEl.style.display = "none";
        }
      }

      if (isPremiumActive) {
        const freeWarnModal = $("freeWarningModal");
        if (freeWarnModal) freeWarnModal.style.display = "none";
        localStorage.removeItem("free_warned_" + user.uid);

        if (userPlan === "premium" && !isExpired) {
          const notifiedKey = "premium_notified_" + user.uid;
          if (localStorage.getItem(notifiedKey) !== "true") {
            const congratsModal = $("congratsModal");
            if (congratsModal) congratsModal.style.display = "flex";
            localStorage.setItem(notifiedKey, "true");
          }
        }
      } else {
        localStorage.removeItem("premium_notified_" + user.uid);

        const freeNotifiedKey = "free_warned_" + user.uid;
        if (localStorage.getItem(freeNotifiedKey) !== "true") {
          const freeWarnModal = $("freeWarningModal");
          if (freeWarnModal) freeWarnModal.style.display = "flex";
          localStorage.setItem(freeNotifiedKey, "true");
        }
      }

      const templateSelect = $("templateSelect");
      const premiumTemplates = ["v1dzy", "template_v2", "slicedrive", "template_v5"];
      if (templateSelect) {
        Array.from(templateSelect.options).forEach((opt) => {
          if (premiumTemplates.includes(opt.value)) {
            if (!isPremiumActive) {
              opt.disabled = true;
              if (!opt.textContent.includes("🔒")) {
                opt.textContent = `🔒 ${opt.textContent} (Premium Only)`;
              }
              opt.style.color = "#555";
            } else {
              opt.disabled = false;
              opt.textContent = opt.textContent.replace("🔒 ", "").replace(" (Premium Only)", "");
              opt.style.color = "";
            }
          }
        });
      }

      loadDomains(userPlan, isExpired, userRole);

      if ($("adminPanelBtn")) {
        $("adminPanelBtn").style.display = userRole === "admin" ? "block" : "none";
      }
    });
  } else {
    location.href = "/";
  }
});

/* =========================
   INIT
========================= */
document.addEventListener("DOMContentLoaded", () => {
  const select = $("templateSelect");
  if (select) {
    select.addEventListener("change", () => {
      window.toggleTemplateFields();
    });
  }

  window.toggleTemplateFields();
});