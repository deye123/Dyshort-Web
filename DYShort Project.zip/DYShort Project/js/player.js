const video = document.getElementById("video");
const overlay = document.getElementById("playOverlay");
const messageBox = document.getElementById("messageBox");
const messageText = document.getElementById("messageText");
let supposedCurrentTime = 0;
video.addEventListener('timeupdate', () => {
  if (!video.seeking) {
    supposedCurrentTime = video.currentTime;
  }
});
video.addEventListener('seeking', () => {
  const delta = video.currentTime - supposedCurrentTime;
  if (delta > 0) {
    video.currentTime = supposedCurrentTime;
  }
});
video.addEventListener('ratechange', () => {
  if (video.playbackRate !== 1) {
    video.playbackRate = 1;
  }
});
const params = new URLSearchParams(location.search);
let rawSlug = params.get("slug");
if (!rawSlug) {
  rawSlug = location.pathname.replace(/^\/+|\/+$/g, "");
}
let slug = (rawSlug || "").trim();
if (slug.toLowerCase().endsWith(".mp4")) {
  slug = slug.slice(0, -4).replace(/\./g, "_") + "_mp4";
} else {
  slug = slug.replace(/\./g, "_");
}
function showMessage(title, text) {
  messageBox.style.display = "flex";
  messageBox.querySelector("h1").textContent = title;
  messageText.textContent = text;
}
function unlockedKey() {
  return "video_unlocked_" + slug;
}
function isUnlocked() {
  return sessionStorage.getItem(unlockedKey()) === "1";
}
function setUnlocked() {
  sessionStorage.setItem(unlockedKey(), "1");
}
function enablePlayerMode() {
  if (overlay) {
    overlay.classList.add("hidden");
    overlay.style.display = "none";
    overlay.style.pointerEvents = "none";
  }
  video.controls = true;
  video.setAttribute("controlsList", "nodownload noremoteplayback noplaybackrate");
  video.disablePictureInPicture = true;
  video.style.pointerEvents = "auto";
  video.pause();
}
async function init() {
  try {
    if (!slug) {
      showMessage("404", "Slug tidak ditemukan");
      return;
    }
    const apiRes = await fetch(`/api/get-link?slug=${encodeURIComponent(slug)}`);
    
    if (!apiRes.ok) {
      showMessage("404", "Link tidak ditemukan di server");
      return;
    }
    const resJson = await apiRes.json();
    if (!resJson.success || !resJson.data) {
      showMessage("404", "Data gagal dimuat");
      return;
    }
    const data = resJson.data;
    const fields = data.fields || {};
    const videoUrl = (fields.videoUrl || "").trim();
    const redirectUrl = `/go/${encodeURIComponent(slug)}/button`;
    if (!videoUrl) {
      showMessage("ERROR", "Video URL tidak ditemukan");
      return;
    }
    
    if (data.expiredAt && Date.now() > data.expiredAt) {
      showMessage("EXPIRED", "Link expired");
      return;
    }
    video.src = videoUrl;
    video.load();
    if (isUnlocked()) {
      enablePlayerMode();
      return;
    }
    video.controls = true;
    let redirecting = false;
    function goRedirect(e) {
      if (e) e.preventDefault();
      if (redirecting) return;
      redirecting = true;
      setUnlocked();
      
      // Kirim sinyal ke server bahwa user masuk ke iklan
      fetch("/api/track-ad", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug: slug })
      }).catch(err => console.error(err)).finally(() => {
        // Pindah ke link iklan setelah sinyal terkirim
        window.location.href = redirectUrl;
      });
    }
    overlay.addEventListener("click", goRedirect);
    overlay.addEventListener("touchstart", goRedirect, { passive: false });
    window.addEventListener("pageshow", () => {
      if (isUnlocked()) {
        enablePlayerMode();
      }
    });
    window.addEventListener("focus", () => {
      if (isUnlocked()) {
        enablePlayerMode();
      }
    });
  } catch (err) {
    console.error(err);
    showMessage("ERROR", "Terjadi kesalahan jaringan");
  }
}
init();