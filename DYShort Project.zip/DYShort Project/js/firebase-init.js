// firebase-init.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
const firebaseConfig = {
  apiKey: "AIzaSyBYWLLSxAdWQh8l_gFTVVpoHu90AM4Pit4",
  authDomain: "auth.dyshort.pro",
  databaseURL: "https://dyaltheme-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "dyaltheme",
  storageBucket: "dyaltheme.firebasestorage.app",
  messagingSenderId: "273589813698",
  appId: "1:273589813698:web:10bee0ed5a59a8624ad65b"
};
const app = initializeApp(firebaseConfig);
export default app;