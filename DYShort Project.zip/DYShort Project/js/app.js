window.APP_CONFIG = {

  firebase: {

    apiKey:
    "AIzaSyBYWLLSxAdWQh8l_gFTVVpoHu90AM4Pit4",

    authDomain:
    "auth.dyshort.pro",

    databaseURL:
    "https://dyaltheme-default-rtdb.asia-southeast1.firebasedatabase.app",

    projectId:
    "dyaltheme",

    storageBucket:
    "dyaltheme.firebasestorage.app",

    messagingSenderId:
    "273589813698",

    appId:
    "1:273589813698:web:10bee0ed5a59a8624ad65b"

  },

  domain: {

    main:
    "https://dyshort.pro",

    bio:
    "https://waae.my.id",

    uploadAPI:
    "https://cdn.dyshort.pro"

  },

  vapidKey:
  "BJcGTtaxWsDZPcpuXCb9alViCD9CGd7v_Eyg0pu4hCOFZo6hC1xwLGzJebk20SDNPQZcHEp1t-JRNW98xsHTF5I"

};

/* MENU */

window.toggleMenu = function(){

  const menu =
    document.getElementById("mobileMenu");

  if(!menu) return;

  menu.style.display =
    menu.style.display === "flex"
    ? "none"
    : "flex";

};

/* TOAST */

window.showToast = function(
  text,
  type="success"
){

  const toast =
    document.getElementById("toast");

  const toastText =
    document.getElementById("toastText");

  if(!toast || !toastText) return;

  toast.className = type;

  toast.style.display = "block";

  toastText.textContent = text;

  clearTimeout(window.toastTimer);

  window.toastTimer = setTimeout(()=>{

    toast.style.display = "none";

  },3000);

};

/* COOKIE */

window.acceptCookies = function(){

  localStorage.setItem(
    "cookieAccepted",
    "true"
  );

  const banner =
    document.getElementById(
      "cookieBanner"
    );

  if(banner){

    banner.style.display = "none";

  }

};

window.addEventListener("load",()=>{

  const banner =
    document.getElementById(
      "cookieBanner"
    );

  if(
    banner &&
    !localStorage.getItem(
      "cookieAccepted"
    )
  ){

    banner.style.display = "block";

  }

});

/* SERVICE WORKER */

if("serviceWorker" in navigator){

  window.addEventListener("load",()=>{

    navigator.serviceWorker
      .register("/sw.js")
      .catch(console.error);

  });

}