import { getDatabase, ref, onValue } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js';
import firebaseApp from '/js/firebase-init.js';

const db = getDatabase(firebaseApp);
const CACHE_VERSION_KEY = 'dyshort_cache_version';

// Daftarkan service worker jika belum terdaftar (aman dipanggil berkali-kali)
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch((err) => {
    console.error('Gagal mendaftarkan service worker:', err);
  });
}

onValue(ref(db, 'settings/cacheVersion'), (snapshot) => {
  const remoteVersion = snapshot.val();
  if (!remoteVersion) return;

  const localVersion = localStorage.getItem(CACHE_VERSION_KEY);

  if (localVersion === null) {
    // Kunjungan pertama di perangkat ini: catat versi saat ini, tidak perlu reload
    localStorage.setItem(CACHE_VERSION_KEY, String(remoteVersion));
    return;
  }

  if (localVersion !== String(remoteVersion)) {
    forceClearAndReload(remoteVersion);
  }
});

async function forceClearAndReload(newVersion) {
  try {
    // 1. Minta service worker aktif untuk hapus semua Cache Storage miliknya
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg && reg.active) {
        reg.active.postMessage({ type: 'CLEAR_ALL_CACHES' });
      }
    }

    // 2. Hapus juga langsung dari halaman, sebagai jaring pengaman
    if (window.caches) {
      const keys = await caches.keys();
      await Promise.all(keys.map((key) => caches.delete(key)));
    }

    localStorage.setItem(CACHE_VERSION_KEY, String(newVersion));
  } catch (err) {
    console.error('Gagal membersihkan cache lokal:', err);
  } finally {
    // 3. Reload paksa supaya file terbaru langsung diambil dari network
    window.location.reload();
  }
}