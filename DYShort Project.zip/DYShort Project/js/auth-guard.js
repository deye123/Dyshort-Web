/**
 * AUTH GUARD - Proteksi halaman dari akses tanpa login
 * File: js/auth-guard.js
 */

(function() {
  console.log("🔐 Auth Guard initialized");

  const checkAuth = async () => {
    try {
      // Tunggu Firebase siap
      if (typeof firebase === 'undefined') {
        console.warn('⏳ Firebase belum loaded, tunggu...');
        setTimeout(checkAuth, 500);
        return;
      }

      // Ambil auth instance
      const auth = firebase.auth || window.auth;
      if (!auth) {
        console.error('❌ Auth tidak tersedia');
        setTimeout(checkAuth, 1000);
        return;
      }

      // Check current user
      const user = auth.currentUser;
      if (!user) {
        console.warn('⚠️ No user logged in, redirecting to login...');
        setTimeout(() => {
          console.log('🚀 Redirect ke login page');
          location.href = '/';
        }, 500);
      } else {
        console.log('✅ User authenticated:', user.email);
      }
    } catch (err) {
      console.error('❌ Auth check error:', err);
    }
  };

  // Jalankan check auth
  checkAuth();
})();