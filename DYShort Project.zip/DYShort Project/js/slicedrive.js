document.addEventListener("DOMContentLoaded", () => {
  const player = document.getElementById("player");
  const btnNext = document.getElementById("btnNext");
  const statusBox = document.getElementById("status");
  const siteTitle = document.getElementById("siteTitle");
  const siteFooter = document.getElementById("siteFooter");

  if (!player || !btnNext) return;

  const state = {
    slug: "",
    videoUrls: [],
    buttonUrl: "",        
    autoRedirectUrl: "",  
    currentVideoUrl: "",
    lastKnownTime: 0,
    saveTimer: null,
    adTriggered: false,
    redirectTimer: null, 
    adClickSent: false // Kunci pengaman agar Ad Clicks cuma 1x
  };

  function showStatus(message) {
    if (!statusBox) return;
    statusBox.textContent = message;
    statusBox.style.display = "block";
  }

  function hideStatus() {
    if (!statusBox) return;
    statusBox.style.display = "none";
    statusBox.textContent = "";
  }

  function getSlugFromPath() {
    let path = window.location.pathname.replace(/^\/+|\/+$/g, "");
    let isMp4 = false;

    if (path.toLowerCase().endsWith(".mp4")) {
      path = path.slice(0, -4);
      isMp4 = true;
    }

    let slug = path.replace(/\./g, "_");
    if (isMp4 && !slug.endsWith("_mp4")) slug += "_mp4";
    return slug;
  }

  function normalizeVideoUrls(input) {
    if (!input) return [];
    if (Array.isArray(input)) return input.map((item) => String(item || "").trim()).filter(Boolean);
    if (typeof input === "string") return input.split("\n").map((s) => s.trim()).filter(Boolean);
    return [];
  }

  function pickRandomVideo(urls, excludeUrl = "") {
    if (!urls.length) return "";
    if (urls.length === 1) return urls[0];
    const filtered = urls.filter((u) => u !== excludeUrl);
    const pool = filtered.length ? filtered : urls;
    return pool[Math.floor(Math.random() * pool.length)] || "";
  }

  function getVideoKey() { return `slicedrive_video_${state.slug || "default"}`; }
  function getTimeKey() { return `slicedrive_time_${state.slug || "default"}`; }
  function getAdKey() { return `slicedrive_ad_${state.slug || "default"}`; }

  function saveCurrentVideo(url) {
    try { if (state.slug && url) sessionStorage.setItem(getVideoKey(), url); } catch (_) {}
  }

  function getSavedVideo() {
    try { return sessionStorage.getItem(getVideoKey()) || ""; } catch (_) { return ""; }
  }

  function saveCurrentTime() {
    try { if (state.slug && player.currentSrc) sessionStorage.setItem(getTimeKey(), String(player.currentTime || 0)); } catch (_) {}
  }

  function restoreCurrentTime() {
    try {
      const saved = sessionStorage.getItem(getTimeKey());
      const time = parseFloat(saved || "");
      if (!Number.isNaN(time) && time > 0) player.currentTime = time;
    } catch (_) {}
  }

  function clearSaveTimer() {
    if (state.saveTimer) { clearInterval(state.saveTimer); state.saveTimer = null; }
  }

  function loadVideo(url) {
    if (!url) return;
    state.currentVideoUrl = url;
    player.src = url;
    player.load();
    restoreCurrentTime();
    hideStatus();
  }

  // FUNGSI PENGAMAN AD CLICKS
  async function safeTrackAdClick() {
    if (state.adClickSent) return; // Jika sudah terkirim, hentikan!
    state.adClickSent = true;      // Kunci
    await trackAdClick(state.slug);
  }

  async function loadLinkData() {
    state.slug = getSlugFromPath();

    if (!state.slug) {
      showStatus("Slug tidak ditemukan.");
      btnNext.disabled = true;
      return;
    }

    // CATATAN: Tidak ada pemanggilan API 'Clicks' di sini karena Worker.js Anda 
    // sudah otomatis menghitung Clicks saat pengguna membuka link.

    try {
      const res = await fetch(`/api/get-link?slug=${encodeURIComponent(state.slug)}`, { cache: "no-store" });
      const json = await res.json();
      
      if (!json.success || !json.data) {
        showStatus("Data link tidak ditemukan.");
        btnNext.disabled = true;
        return;
      }

      const data = json.data;
      const fields = data.fields || {};

      state.videoUrls = normalizeVideoUrls(fields.videoUrls || fields.videoUrl || []);
      state.buttonUrl = `/go/${encodeURIComponent(state.slug)}/button`;
      state.autoRedirectUrl = `/go/${encodeURIComponent(state.slug)}/redirect`;

      const titleText = String(data.ogTitle || data.title || "DYShort").trim();
      const descText = String(data.ogDesc || "").trim();
      const imageText = String(data.ogImage || "").trim();

      if (siteTitle) siteTitle.textContent = "DYShort";
      document.title = titleText || "DYShort";

      const ogTitle = document.querySelector('meta[property="og:title"]');
      const ogDesc = document.querySelector('meta[property="og:description"]');
      const ogImage = document.querySelector('meta[property="og:image"]');

      if (ogTitle) ogTitle.setAttribute("content", titleText || "DYShort");
      if (ogDesc) ogDesc.setAttribute("content", descText);
      if (ogImage) ogImage.setAttribute("content", imageText);

      if (siteFooter) siteFooter.textContent = descText || "";

      if (!state.videoUrls.length) {
        showStatus("Tidak ada video URL yang tersimpan untuk template ini.");
        btnNext.disabled = true;
        return;
      }

      let chosen = getSavedVideo();

      if (!chosen || !state.videoUrls.includes(chosen)) {
        chosen = pickRandomVideo(state.videoUrls);
        saveCurrentVideo(chosen);
      }

      try {
        if (sessionStorage.getItem(getAdKey()) === "true") {
          state.adTriggered = true;
        }
      } catch (_) {}

      loadVideo(chosen);
      btnNext.disabled = false;
    } catch (err) {
      console.error(err);
      showStatus("Gagal memuat data video.");
      btnNext.disabled = true;
    }
  }

  player.addEventListener("loadedmetadata", restoreCurrentTime);
  player.addEventListener("pause", saveCurrentTime);
  player.addEventListener("ended", saveCurrentTime);

  // 1. EVENT AUTO-REDIRECT BERDASARKAN DURASI ASLI
  player.addEventListener("timeupdate", async () => { 
    state.lastKnownTime = player.currentTime || 0; 
    
    // Aktif HANYA jika sudah lewat 5 detik video berjalan & belum pernah redirect
    if (!state.adTriggered && state.lastKnownTime >= 5) {
      state.adTriggered = true; 
      
      try { sessionStorage.setItem(getAdKey(), "true"); } catch (_) {}

      if (state.autoRedirectUrl) {
        player.pause(); 
        saveCurrentTime();
        await safeTrackAdClick();
        window.location.href = state.autoRedirectUrl;
      }
    }
  });

  // 2. EVENT TOMBOL NEXT VIDEO
  btnNext.addEventListener("click", async () => {
    if (!state.buttonUrl || btnNext.disabled) return; 
    btnNext.disabled = true; 
    await safeTrackAdClick(); 
    sessionStorage.removeItem(getVideoKey());
    sessionStorage.removeItem(getTimeKey());
    try { sessionStorage.removeItem(getAdKey()); } catch (_) {}
    window.location.href = state.buttonUrl;
  });

  window.addEventListener("beforeunload", () => {
    if (sessionStorage.getItem(getVideoKey())) saveCurrentTime();
    clearSaveTimer();
  });

  state.saveTimer = setInterval(() => {
    if (sessionStorage.getItem(getVideoKey())) saveCurrentTime();
  }, 1000);
  
  window.addEventListener("pageshow", (event) => {
    if (event.persisted) {
      state.adClickSent = false;
      try {
        state.adTriggered = sessionStorage.getItem(getAdKey()) === "true";
      } catch (_) {
        state.adTriggered = false;
      }
      btnNext.disabled = false;
    }
  });

  loadLinkData();
});

async function trackAdClick(slug) {
  try {
    await fetch('/api/track-ad', { 
      method: 'POST', 
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ slug: slug }),
      keepalive: true 
    });
  } catch (e) { 
    console.error("Gagal track Ad:", e); 
  }
}
