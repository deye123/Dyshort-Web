import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

import {
  getAuth,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signOut
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import { 
  getDatabase, 
  ref, 
  update 
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-database.js";

/* =========================
   FIREBASE CONFIG
========================= */
const firebaseConfig = {
  apiKey: "AIzaSyBYWLLSxAdWQh8l_gFTVVpoHu90AM4Pit4",
  authDomain: "auth.dyshort.pro",
  projectId: "dyaltheme",
  // 🔥 PERBAIKAN 1: URL Database Wajib Diisi agar tidak nyasar ke server US
  databaseURL: "https://dyaltheme-default-rtdb.asia-southeast1.firebasedatabase.app",
  storageBucket: "dyaltheme.firebasestorage.app",
  messagingSenderId: "273589813698",
  appId: "1:273589813698:web:10bee0ed5a59a8624ad65b"
};

/* =========================
   INIT
========================= */
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

// 🔥 PERBAIKAN 2: Flag untuk menahan redirect sampai data selesai masuk DB
window.isProcessingAuth = false;

/* =========================
   FUNGSi HELPER SIMPAN DATA USER
========================= */
async function saveUserData(user) {
  try {
    const userRef = ref(db, 'users/' + user.uid);
    await update(userRef, {
      uid: user.uid,
      email: user.email,
      lastLogin: Date.now(),
      updatedAt: Date.now()
    });
    console.log("💾 Data user berhasil disinkronkan ke Realtime Database.");
  } catch (error) {
    console.error("❌ Gagal menyimpan data user ke database:", error);
    
    // Beri peringatan jelas ke layar
    alert("DATABASE REJECTED: " + error.message + "\n\nSesi di-logout otomatis karena gagal sinkronisasi data.");
    
    // 🔥 PAKSA LOGOUT: Karena Auth-nya sukses tapi DB-nya gagal. 
    // Supaya session-nya gak nyangkut pas halaman di-refresh.
    await signOut(auth).catch(() => {});
    
    window.isProcessingAuth = false; 
    throw error; // Tetap lempar error untuk membatalkan redirect di fungsi utama
  }
}

/* =========================
   UI SCRIPTS
========================= */
window.togglePassword = function(inputId, iconId) {
  const input = document.getElementById(inputId);
  const icon = document.getElementById(iconId);
  if (input.type === "password") {
    input.type = "text";
    icon.innerHTML = '<path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path><line x1="2" y1="2" x2="22" y2="22"></line>';
  } else {
    input.type = "password";
    icon.innerHTML = '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle>';
  }
};

window.showToast = function(text, type="success") {
  const toast = document.getElementById("toast");
  toast.className = type + " show";
  toast.textContent = text;
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => {
    toast.className = type; 
  }, 3000);
};

const showToast = window.showToast;

async function verifyTurnstileToken(token) {
  try {
    const response = await fetch("https://dyshort-worker.myling.workers.dev/api/verify-turnstile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token })
    });
    const data = await response.json();
    return data.success;
  } catch (err) {
    console.error("Turnstile error:", err);
    return false; 
  }
}

/* =========================
   CHECK AUTH STATE
========================= */
onAuthStateChanged(auth, (user) => {
  // Hanya redirect jika user buka halaman dan SUDAH login sebelumnya, 
  // BUKAN saat sedang proses klik tombol login (dicegah oleh isProcessingAuth)
  if (user && !window.isProcessingAuth) {
    setTimeout(() => {
      location.href = "home.html";
    }, 1000);
  }
});

/* =========================
   MODAL
========================= */
window.openRegisterModal = function(){ document.getElementById("registerModal").style.display = "flex"; };
window.closeRegisterModal = function(){ document.getElementById("registerModal").style.display = "none"; };

/* =========================
   LOGIN EMAIL
========================= */
window.loginEmail = async function(){
  try{
    const turnstileEl = document.querySelector('.login-wrapper [name="cf-turnstile-response"]');
    const token = turnstileEl ? turnstileEl.value : null;

    if(!token){ return showToast("Complete verification", "error"); }
    const isHuman = await verifyTurnstileToken(token);
    if(!isHuman){
      if(window.turnstile) window.turnstile.reset();
      return showToast("Bot terdeteksi atau token kadaluarsa!", "error");
    }

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    if(!email || !password){ return showToast("Complete all fields", "error"); }

    window.isProcessingAuth = true; // Tahan redirect otomatis dari onAuthStateChanged
    
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    await saveUserData(userCredential.user); // Tunggu sampai DB selesai update

    showToast("Login success");
    setTimeout(()=>{ location.href = "home.html"; }, 1000);

  }catch(err){
    window.isProcessingAuth = false;
    let msg = err.message;
    if(err.code === "auth/invalid-credential") msg = "Wrong email or password";
    showToast(msg, "error");
  }
};

/* =========================
   RESET PASSWORD
========================= */
window.forgotPassword = async function(){
  const email = document.getElementById("email").value.trim();
  if(!email){ return showToast("Enter your email first", "error"); }
  try{
    await sendPasswordResetEmail(auth, email);
    showToast("Reset password email sent");
  }catch(err){
    let msg = err.message;
    if(err.code === "auth/user-not-found") msg = "Email not registered";
    showToast(msg, "error");
  }
};

/* =========================
   REGISTER
========================= */
window.registerFromModal = async function(){
  try{
    const turnstileEl = document.getElementById('registerCaptcha').querySelector('[name="cf-turnstile-response"]');
    const token = turnstileEl ? turnstileEl.value : null;

    if(!token){ return showToast("Complete verification", "error"); }
    const isHuman = await verifyTurnstileToken(token);
    if(!isHuman){
      if(window.turnstile) window.turnstile.reset('registerCaptcha');
      return showToast("Bot terdeteksi! (Cek Console)", "error");
    }

    const email = document.getElementById("regEmail").value.trim();
    const password = document.getElementById("regPassword").value;
    const confirm = document.getElementById("regPassword2").value;

    if(!email || !password || !confirm){ return showToast("Complete all fields", "error"); }
    if(password.length < 8){ return showToast("Minimum password 8 characters", "error"); }
    if(password !== confirm){ return showToast("Password does not match", "error"); }

    window.isProcessingAuth = true; // Tahan redirect otomatis

    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    await saveUserData(userCredential.user); // Tunggu sampai DB selesai update

    showToast("Account created");
    closeRegisterModal();
    setTimeout(()=>{ location.href = "home.html"; }, 1000);

  }catch(err){
    window.isProcessingAuth = false;
    let msg = err.message;
    if(err.code === "auth/email-already-in-use") msg = "Email already used";
    showToast(msg, "error");
  }
};

/* =========================
   GOOGLE LOGIN
========================= */
window.loginGoogle = async function(){
  try{
    window.isProcessingAuth = true; // Tahan redirect otomatis
    
    const provider = new GoogleAuthProvider();
    const userCredential = await signInWithPopup(auth, provider);
    await saveUserData(userCredential.user); // Tunggu sampai DB selesai update

    showToast("Google login success");
    setTimeout(()=>{ location.href = "home.html"; }, 800);

  }catch(err){
    window.isProcessingAuth = false;
    console.error(err);
    showToast(err.message, "error");
  }
};

/* =========================
   ENTER SUPPORT
========================= */
document.addEventListener("keydown", (e)=>{
  if(e.key === "Enter"){ loginEmail(); }
});